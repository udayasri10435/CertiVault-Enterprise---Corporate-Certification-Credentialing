import React, { useState, useEffect } from 'react';
import { Certification, Industry } from './types/credential';
import { INITIAL_CREDENTIALS } from './data/initialCredentials';
import { Header, ActiveView } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { CredentialsLedgerView } from './components/CredentialsLedgerView';
import { VerificationPortalView } from './components/VerificationPortalView';
import { ExpirationsView } from './components/ExpirationsView';
import { CertificateModal } from './components/CertificateModal';
import { BlockchainLedgerModal } from './components/BlockchainLedgerModal';
import { RenewalModal } from './components/RenewalModal';
import { RevokeModal } from './components/RevokeModal';
import { IssueCredentialModal } from './components/IssueCredentialModal';
import { calculateSHA256, getCanonicalCredentialPayload } from './utils/crypto';

const STORAGE_KEY = 'certivault_enterprise_credentials_v1';

export default function App() {
  const [credentials, setCredentials] = useState<Certification[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch (err) {
        console.error('Failed to load saved credentials:', err);
      }
    }
    return INITIAL_CREDENTIALS;
  });

  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [selectedCertForCertificate, setSelectedCertForCertificate] = useState<Certification | null>(null);
  const [selectedCertForBlockchain, setSelectedCertForBlockchain] = useState<Certification | null>(null);
  const [selectedCertForRenewal, setSelectedCertForRenewal] = useState<Certification | null>(null);
  const [selectedCertForRevoke, setSelectedCertForRevoke] = useState<Certification | null>(null);
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [verificationPrefillId, setVerificationPrefillId] = useState<string>('');

  // Persist credentials whenever updated
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(credentials));
    } catch (err) {
      console.error('Failed to save credentials to localStorage:', err);
    }
  }, [credentials]);

  // Handle new issued certifications (single or batch)
  const handleIssuedCredentials = (newCerts: Certification[]) => {
    setCredentials((prev) => [...newCerts, ...prev]);
    // Automatically preview first certificate if single
    if (newCerts.length === 1) {
      setSelectedCertForCertificate(newCerts[0]);
    }
  };

  // Handle renewal
  const handleRenewCredential = async (
    certId: string,
    renewalData: {
      newExpiration: string;
      ceuSubmitted: number;
      authorizedBy: string;
      notes: string;
    }
  ) => {
    const updated = await Promise.all(
      credentials.map(async (c) => {
        if (c.id !== certId) return c;

        const newRecord = {
          id: `REN-${Date.now()}`,
          renewedAt: new Date().toISOString(),
          previousExpiration: c.expirationDate,
          newExpiration: renewalData.newExpiration,
          authorizedBy: renewalData.authorizedBy,
          ceuSubmitted: renewalData.ceuSubmitted,
          notes: renewalData.notes,
        };

        const updatedCert: Certification = {
          ...c,
          expirationDate: renewalData.newExpiration,
          status: 'ACTIVE',
          ceuCredits: c.ceuCredits + renewalData.ceuSubmitted,
          renewalHistory: [...c.renewalHistory, newRecord],
        };

        // Recalculate hash for updated credential
        const canonical = getCanonicalCredentialPayload(updatedCert);
        updatedCert.verificationHash = await calculateSHA256(canonical);

        return updatedCert;
      })
    );

    setCredentials(updated);
  };

  // Handle administrative revocation
  const handleRevokeCredential = async (
    certId: string,
    revocationData: {
      reason: string;
      revokedBy: string;
      noticeRef: string;
    }
  ) => {
    const updated = credentials.map((c) => {
      if (c.id !== certId) return c;

      return {
        ...c,
        status: 'REVOKED' as const,
        revocation: {
          revokedAt: new Date().toISOString(),
          reason: revocationData.reason,
          revokedBy: revocationData.revokedBy,
          noticeRef: revocationData.noticeRef,
        },
      };
    });

    setCredentials(updated);
  };

  // Quick navigation helpers
  const handleNavigateToLedger = (industry?: Industry) => {
    setActiveView('ledger');
  };

  const handleOpenVerifyWithId = (certId?: string) => {
    if (certId) {
      setVerificationPrefillId(certId);
    }
    setActiveView('verification');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header conforming to 3-zone contract */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenIssue={() => setIsIssueModalOpen(true)}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeView === 'dashboard' && (
          <DashboardView
            credentials={credentials}
            onNavigateToLedger={handleNavigateToLedger}
            onOpenIssue={() => setIsIssueModalOpen(true)}
            onOpenCertificate={(c) => setSelectedCertForCertificate(c)}
            onOpenRenewal={(c) => setSelectedCertForRenewal(c)}
            onOpenVerify={handleOpenVerifyWithId}
          />
        )}

        {activeView === 'ledger' && (
          <CredentialsLedgerView
            credentials={credentials}
            onOpenCertificate={(c) => setSelectedCertForCertificate(c)}
            onOpenRenewal={(c) => setSelectedCertForRenewal(c)}
            onOpenRevoke={(c) => setSelectedCertForRevoke(c)}
            onOpenBlockchain={(c) => setSelectedCertForBlockchain(c)}
            onOpenVerify={handleOpenVerifyWithId}
            onOpenIssue={() => setIsIssueModalOpen(true)}
          />
        )}

        {activeView === 'verification' && (
          <VerificationPortalView
            credentials={credentials}
            onOpenCertificate={(c) => setSelectedCertForCertificate(c)}
            onOpenBlockchain={(c) => setSelectedCertForBlockchain(c)}
            prefillId={verificationPrefillId}
          />
        )}

        {activeView === 'expirations' && (
          <ExpirationsView
            credentials={credentials}
            onOpenRenewal={(c) => setSelectedCertForRenewal(c)}
            onOpenCertificate={(c) => setSelectedCertForCertificate(c)}
          />
        )}
      </main>

      {/* Clean quiet footer */}
      <footer className="border-t border-slate-800 bg-slate-900/60 py-6 px-6 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">CertiVault Enterprise</span>
            <span>·</span>
            <span>Accredited Certification & Credentialing Infrastructure</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>ISO/IEC 17024:2012</span>
            <span>·</span>
            <span>W3C Verifiable Credentials</span>
            <span>·</span>
            <span>Polygon PoS Anchoring</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <CertificateModal
        cert={selectedCertForCertificate}
        onClose={() => setSelectedCertForCertificate(null)}
        onVerifyClick={(id) => handleOpenVerifyWithId(id)}
        onOpenBlockchain={(cert) => setSelectedCertForBlockchain(cert)}
      />

      <BlockchainLedgerModal
        cert={selectedCertForBlockchain}
        onClose={() => setSelectedCertForBlockchain(null)}
      />

      <RenewalModal
        cert={selectedCertForRenewal}
        onClose={() => setSelectedCertForRenewal(null)}
        onRenew={handleRenewCredential}
      />

      <RevokeModal
        cert={selectedCertForRevoke}
        onClose={() => setSelectedCertForRevoke(null)}
        onRevoke={handleRevokeCredential}
      />

      <IssueCredentialModal
        isOpen={isIssueModalOpen}
        onClose={() => setIsIssueModalOpen(false)}
        onIssued={handleIssuedCredentials}
      />
    </div>
  );
}
