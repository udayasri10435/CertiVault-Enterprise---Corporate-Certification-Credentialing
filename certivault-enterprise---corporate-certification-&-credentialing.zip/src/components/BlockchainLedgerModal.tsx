import React, { useState } from 'react';
import { Certification } from '../types/credential';
import { X, Copy, Check, Blocks, ShieldCheck, ExternalLink, Hash, Database } from 'lucide-react';

interface BlockchainLedgerModalProps {
  cert: Certification | null;
  onClose: () => void;
}

export const BlockchainLedgerModal: React.FC<BlockchainLedgerModalProps> = ({ cert, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!cert || !cert.blockchain.enabled) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const blockchain = cert.blockchain;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <Blocks className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-semibold text-white tracking-tight">
                Enterprise Blockchain Anchor & Proof Log
              </h2>
              <p className="text-xs text-slate-400">
                Immutable cryptographic ledger anchoring record
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-sm">
          {/* Status overview */}
          <div className="p-4 bg-slate-800/60 border border-slate-700/60 rounded-lg flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="font-semibold text-white">
                Cryptographically Anchored & Invariant
              </div>
              <p className="text-slate-300 leading-relaxed">
                This credential&apos;s SHA-256 state digest is anchored into the decentralized enterprise consortium ledger.
                Any retroactive alteration of the recipient, issue date, or competencies will fail the Merkle inclusion proof.
              </p>
            </div>
          </div>

          {/* Key-Value Fields */}
          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                Ledger Network
              </div>
              <div className="flex items-center justify-between">
                <span className="text-indigo-300 font-semibold">{blockchain.network || 'Polygon PoS Enterprise'}</span>
                <span className="text-[11px] text-slate-400 font-sans">Chain ID: 137 / Consortia Private Subnet</span>
              </div>
            </div>

            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                Transaction Hash (TxHash)
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-200 truncate">{blockchain.txHash}</span>
                <button
                  onClick={() => copyToClipboard(blockchain.txHash || '', 'tx')}
                  className="p-1 text-slate-400 hover:text-white shrink-0"
                  title="Copy Tx Hash"
                >
                  {copiedKey === 'tx' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                  Block Height / Number
                </div>
                <div className="text-white font-semibold tabular-nums">
                  #{blockchain.blockNumber?.toLocaleString() || '49,102,834'}
                </div>
              </div>

              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                  Anchor Timestamp
                </div>
                <div className="text-slate-300">
                  {blockchain.anchoredAt ? new Date(blockchain.anchoredAt).toUTCString() : 'N/A'}
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                Anchored Smart Contract Registry
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-200 truncate">{blockchain.contractAddress}</span>
                <button
                  onClick={() => copyToClipboard(blockchain.contractAddress || '', 'contract')}
                  className="p-1 text-slate-400 hover:text-white shrink-0"
                  title="Copy Contract Address"
                >
                  {copiedKey === 'contract' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400 uppercase font-sans font-medium mb-1">
                Credential Payload SHA-256 Merkle Root
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-300 truncate">{blockchain.merkleRoot}</span>
                <button
                  onClick={() => copyToClipboard(blockchain.merkleRoot || '', 'merkle')}
                  className="p-1 text-slate-400 hover:text-white shrink-0"
                  title="Copy Merkle Root"
                >
                  {copiedKey === 'merkle' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* Merkle Proof Tree Diagram */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-2 font-mono">
            <div className="text-slate-400 font-sans text-[11px] font-medium flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              <span>Merkle Tree Inclusion Proof Branch</span>
            </div>
            <div className="text-slate-400 text-[11px] leading-relaxed pl-2 border-l border-slate-700">
              <div>Root [0x{blockchain.merkleRoot?.slice(2, 10)}...]</div>
              <div className="pl-3">└── Node Left: Hash({cert.id})</div>
              <div className="pl-6">├── Leaf 0: StateDigest ({cert.verificationHash.slice(0, 12)}...)</div>
              <div className="pl-6">└── Leaf 1: IssuerSignature (ISO 17024 Accredited)</div>
              <div className="text-emerald-400 font-sans text-[11px] mt-2">
                ✓ Cryptographic inclusion proof verified against block #{blockchain.blockNumber}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs">
          <span className="text-slate-500 font-mono">Status: Confirmed (1,492 confirmations)</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-medium transition-colors"
          >
            Close Explorer
          </button>
        </div>
      </div>
    </div>
  );
};
