import React, { useRef } from 'react';
import { Certification } from '../types/credential';
import { GuillocheBorder } from './GuillocheBorder';
import { SecuritySeal } from './SecuritySeal';
import { QRCodeDisplay } from './QRCodeDisplay';
import { Printer, Download, X, ExternalLink, ShieldCheck, CheckCircle2, Clock, AlertTriangle, Ban } from 'lucide-react';

interface CertificateModalProps {
  cert: Certification | null;
  onClose: () => void;
  onVerifyClick?: (certId: string) => void;
  onOpenBlockchain?: (cert: Certification) => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  cert,
  onClose,
  onVerifyClick,
  onOpenBlockchain,
}) => {
  const certificateRef = useRef<HTMLDivElement>(null);

  if (!cert) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJSON = () => {
    const verifiableCredential = {
      '@context': [
        'https://www.w3.org/2018/credentials/v1',
        'https://w3id.org/security/suites/ed25519-2020/v1'
      ],
      id: `urn:uuid:${cert.id}`,
      type: ['VerifiableCredential', 'CorporateAccreditedCertification'],
      issuer: {
        id: `did:corp:${cert.issuingOrganization.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
        name: cert.issuingOrganization,
      },
      issuanceDate: cert.issueDate,
      expirationDate: cert.expirationDate,
      credentialSubject: {
        id: `urn:corp:employee:${cert.recipientId}`,
        name: cert.recipientName,
        email: cert.recipientEmail,
        certification: cert.credentialTitle,
        industry: cert.industry,
        competencies: cert.competencies,
        ceuCredits: cert.ceuCredits,
      },
      proof: {
        type: 'SHA256WithEnterpriseLedger',
        created: cert.issueDate,
        verificationHash: cert.verificationHash,
        blockchainAnchor: cert.blockchain.enabled ? cert.blockchain : undefined,
      }
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(verifiableCredential, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${cert.id}_verifiable_credential.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getThemeStyling = () => {
    switch (cert.metadata.certificateTheme) {
      case 'emerald_clinical':
        return {
          titleColor: 'text-emerald-950',
          accentText: 'text-emerald-700',
          accentBg: 'bg-emerald-50',
          borderColor: 'border-emerald-700',
          badgeText: 'text-emerald-800',
        };
      case 'amber_industrial':
        return {
          titleColor: 'text-amber-950',
          accentText: 'text-amber-700',
          accentBg: 'bg-amber-50',
          borderColor: 'border-amber-700',
          badgeText: 'text-amber-800',
        };
      case 'modern_dark':
        return {
          titleColor: 'text-slate-900',
          accentText: 'text-blue-700',
          accentBg: 'bg-slate-50',
          borderColor: 'border-slate-800',
          badgeText: 'text-slate-800',
        };
      case 'classic_navy':
      default:
        return {
          titleColor: 'text-blue-950',
          accentText: 'text-blue-800',
          accentBg: 'bg-blue-50',
          borderColor: 'border-blue-900',
          badgeText: 'text-blue-800',
        };
    }
  };

  const themeStyle = getThemeStyling();

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 no-print">
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl max-w-4xl w-full flex flex-col max-h-[92vh] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-base font-semibold text-white tracking-tight">
              Official Credential Certificate
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {cert.id}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
              title="Print Certificate or save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={handleDownloadJSON}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
              title="Download W3C Verifiable Credential standard JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span>W3C JSON</span>
            </button>

            {onVerifyClick && (
              <button
                onClick={() => {
                  onClose();
                  onVerifyClick(cert.id);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-300 bg-blue-950/60 hover:bg-blue-900/80 border border-blue-800 rounded-md transition-colors"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verify Proof</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors ml-2"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Certificate Scrollable Viewport */}
        <div className="overflow-y-auto p-4 sm:p-8 bg-slate-950/60 flex justify-center items-center">
          {/* Real Certificate Printable Surface */}
          <div
            ref={certificateRef}
            className="certificate-print-area relative w-full max-w-[820px] bg-[#fcfbfa] text-slate-900 shadow-xl rounded-xs p-6 sm:p-12 overflow-hidden border border-amber-900/20"
            style={{
              backgroundImage: 'radial-gradient(#e5e7eb 0.5px, transparent 0.5px)',
              backgroundSize: '20px 20px',
            }}
          >
            {/* Guilloche Security Frame */}
            <GuillocheBorder theme={cert.metadata.certificateTheme} />

            {/* Content Container with generous margins */}
            <div className="relative z-10 mx-auto px-4 sm:px-8 py-4 flex flex-col items-center text-center">
              {/* Top Issuer Authority */}
              <div className="text-[11px] font-semibold tracking-widest text-slate-600 uppercase mb-1">
                {cert.issuingOrganization}
              </div>
              <div className="text-[10px] text-slate-500 font-medium tracking-wider uppercase mb-5">
                Accredited under {cert.metadata.accreditationStandard || 'ISO/IEC 17024 Competency Guidelines'}
              </div>

              {/* Title Section */}
              <h1 className="text-xs sm:text-sm font-semibold tracking-[0.25em] uppercase text-amber-700/90 mb-1">
                Certificate of Enterprise Credentialing
              </h1>
              <div className="w-24 h-[1px] bg-amber-600/40 my-2" />

              <p className="text-xs italic text-slate-500 my-1 font-serif">
                This document solemnly attests that
              </p>

              {/* Recipient Name */}
              <div className={`text-2xl sm:text-3xl font-bold tracking-tight my-2 font-serif ${themeStyle.titleColor}`}>
                {cert.recipientName}
              </div>

              <div className="text-xs text-slate-600 mb-3 font-mono">
                Employee Reference ID: <span className="font-semibold text-slate-800">{cert.recipientId}</span>
              </div>

              <p className="text-xs text-slate-600 max-w-lg mx-auto leading-relaxed mb-3">
                has successfully fulfilled all rigorous theoretical examinations, practical workplace assessments,
                and regulatory compliance mandates required for the designation of
              </p>

              {/* Designation Title */}
              <div className="px-6 py-2.5 my-2 border-y border-amber-600/30 max-w-xl">
                <span className={`text-lg sm:text-xl font-bold tracking-wide ${themeStyle.titleColor}`}>
                  {cert.credentialTitle}
                </span>
                <div className="text-xs text-slate-500 font-medium mt-0.5">
                  Industry Classification: <span className="font-semibold">{cert.industry}</span> · {cert.category}
                </div>
              </div>

              {/* Verified Competencies */}
              <div className="my-3 text-left w-full max-w-lg">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500 mb-1.5 text-center">
                  Verified Core Competencies & Subject Masteries
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] text-slate-700">
                  {cert.competencies.map((comp, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-600 font-bold shrink-0">✓</span>
                      <span className="leading-tight">{comp}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Signatures, Seal & QR Code */}
              <div className="w-full mt-6 pt-4 border-t border-slate-200/80 grid grid-cols-3 items-end gap-3 text-center">
                {/* Left: Signatory */}
                <div className="flex flex-col items-center">
                  <div className="font-serif italic text-base text-slate-800 tracking-wide mb-1 border-b border-slate-400 pb-1 w-36 text-center">
                    {cert.authorizedSigner.signatureText || cert.authorizedSigner.name}
                  </div>
                  <div className="text-[10px] font-bold text-slate-800 leading-tight">
                    {cert.authorizedSigner.name}
                  </div>
                  <div className="text-[9px] text-slate-500 leading-tight">
                    {cert.authorizedSigner.title}
                  </div>
                </div>

                {/* Center: Official Seal */}
                <div className="flex flex-col items-center justify-center">
                  <SecuritySeal
                    theme={cert.metadata.certificateTheme}
                    organization={cert.issuingOrganization}
                    size={98}
                  />
                  <div className="text-[9px] font-mono font-medium text-slate-500 mt-1">
                    CEU Credits: <span className="font-bold text-slate-700">{cert.ceuCredits} Hours</span>
                  </div>
                </div>

                {/* Right: QR Code & Dates */}
                <div className="flex flex-col items-center">
                  <QRCodeDisplay
                    value={`https://certivault.enterprise/verify?id=${cert.id}&hash=${cert.verificationHash}`}
                    size={72}
                  />
                  <div className="text-[9px] text-slate-500 mt-1.5 font-mono">
                    Issued: <span className="font-semibold text-slate-700">{cert.issueDate}</span>
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono">
                    Valid Thru: <span className="font-semibold text-slate-700">{cert.expirationDate}</span>
                  </div>
                </div>
              </div>

              {/* Cryptographic Footprint Banner */}
              <div className="w-full mt-5 pt-3 border-t border-slate-200/60 text-[9px] font-mono text-slate-400 flex flex-wrap items-center justify-between gap-2">
                <div className="truncate max-w-[340px]">
                  SHA-256: <span className="text-slate-600 font-semibold">{cert.verificationHash}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {cert.blockchain.enabled ? (
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      On-Chain Anchor ({cert.blockchain.network})
                    </span>
                  ) : (
                    <span className="text-slate-500">Standard Cryptographic Signature</span>
                  )}
                  <span>·</span>
                  <span>ID: {cert.id}</span>
                </div>
              </div>

              {/* Revocation Banner if revoked */}
              {cert.revocation && (
                <div className="w-full mt-3 p-2 bg-red-50 border border-red-200 rounded text-left">
                  <div className="flex items-center gap-1.5 text-red-800 font-bold text-xs">
                    <Ban className="w-4 h-4" />
                    <span>REVOCATION NOTICE ON RECORD</span>
                  </div>
                  <div className="text-[10px] text-red-700 mt-0.5">
                    Revoked on {new Date(cert.revocation.revokedAt).toLocaleDateString()} by {cert.revocation.revokedBy}. Reason: {cert.revocation.reason}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer with details */}
        <div className="px-6 py-3 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-3">
            <span>Status:</span>
            {cert.status === 'ACTIVE' && (
              <span className="text-emerald-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Active & Compliant
              </span>
            )}
            {cert.status === 'EXPIRING_SOON' && (
              <span className="text-amber-400 font-medium flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Renewal Window Open (Expiring Soon)
              </span>
            )}
            {cert.status === 'EXPIRED' && (
              <span className="text-red-400 font-medium flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Expired - Inactive Status
              </span>
            )}
            {cert.status === 'REVOKED' && (
              <span className="text-red-500 font-medium flex items-center gap-1">
                <Ban className="w-3.5 h-3.5" /> Revoked by Authority
              </span>
            )}
          </div>

          {cert.blockchain.enabled && onOpenBlockchain && (
            <button
              onClick={() => onOpenBlockchain(cert)}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-mono inline-flex items-center gap-1 hover:underline"
            >
              <span>View On-Chain Ledger Proof</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
