import React, { useState, useMemo } from 'react';
import { Certification, Industry, CredentialStatus } from '../types/credential';
import { computeCredentialStatus, getDaysRemaining } from '../utils/crypto';
import {
  Search,
  Filter,
  Eye,
  RefreshCw,
  Ban,
  Blocks,
  ShieldCheck,
  Download,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface CredentialsLedgerViewProps {
  credentials: Certification[];
  onOpenCertificate: (cert: Certification) => void;
  onOpenRenewal: (cert: Certification) => void;
  onOpenRevoke: (cert: Certification) => void;
  onOpenBlockchain: (cert: Certification) => void;
  onOpenVerify: (certId: string) => void;
  onOpenIssue: () => void;
}

export const CredentialsLedgerView: React.FC<CredentialsLedgerViewProps> = ({
  credentials,
  onOpenCertificate,
  onOpenRenewal,
  onOpenRevoke,
  onOpenBlockchain,
  onOpenVerify,
  onOpenIssue,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [industryFilter, setIndustryFilter] = useState<'ALL' | Industry>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | CredentialStatus>('ALL');
  const [blockchainFilter, setBlockchainFilter] = useState<'ALL' | 'ANCHORED' | 'OFFCHAIN'>('ALL');

  // Filtered credentials list
  const filteredCredentials = useMemo(() => {
    return credentials.filter((cert) => {
      // Dynamic status calculation
      const currentStatus = computeCredentialStatus(cert);

      // Industry filter
      if (industryFilter !== 'ALL' && cert.industry !== industryFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'ALL' && currentStatus !== statusFilter) {
        return false;
      }

      // Blockchain filter
      if (blockchainFilter === 'ANCHORED' && !cert.blockchain.enabled) {
        return false;
      }
      if (blockchainFilter === 'OFFCHAIN' && cert.blockchain.enabled) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = cert.recipientName.toLowerCase().includes(query);
        const matchesTitle = cert.credentialTitle.toLowerCase().includes(query);
        const matchesId = cert.id.toLowerCase().includes(query);
        const matchesEmail = cert.recipientEmail.toLowerCase().includes(query);
        const matchesEmpId = cert.recipientId.toLowerCase().includes(query);
        const matchesHash = cert.verificationHash.toLowerCase().includes(query);

        return matchesName || matchesTitle || matchesId || matchesEmail || matchesEmpId || matchesHash;
      }

      return true;
    });
  }, [credentials, industryFilter, statusFilter, blockchainFilter, searchQuery]);

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'ID',
      'Recipient Name',
      'Recipient Email',
      'Employee ID',
      'Industry',
      'Credential Title',
      'Status',
      'Issue Date',
      'Expiration Date',
      'CEU Hours',
      'Blockchain Anchored',
      'Blockchain Network',
      'SHA256 Hash'
    ];

    const rows = filteredCredentials.map((c) => [
      c.id,
      `"${c.recipientName}"`,
      c.recipientEmail,
      c.recipientId,
      c.industry,
      `"${c.credentialTitle}"`,
      computeCredentialStatus(c),
      c.issueDate,
      c.expirationDate,
      c.ceuCredits,
      c.blockchain.enabled ? 'YES' : 'NO',
      c.blockchain.network || 'N/A',
      c.verificationHash
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `certivault_credentials_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="space-y-4">
      {/* Controls & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, credential title, ID (CERT-IT-...), email, or SHA-256 hash..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
            />
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleExportCSV}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={onOpenIssue}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <span>+ Issue Credential</span>
            </button>
          </div>
        </div>

        {/* Filter Segment Bars */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-xs">
          {/* Industry Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-[11px] text-slate-500 px-2 font-medium">Industry:</span>
            {(['ALL', 'IT', 'HEALTHCARE', 'TRADES'] as const).map((ind) => (
              <button
                key={ind}
                onClick={() => setIndustryFilter(ind)}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  industryFilter === ind
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {ind === 'ALL' ? 'All Industries' : ind === 'IT' ? 'Information Tech' : ind === 'HEALTHCARE' ? 'Healthcare' : 'Trades'}
              </button>
            ))}
          </div>

          {/* Status Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-[11px] text-slate-500 px-2 font-medium">Status:</span>
            {(['ALL', 'ACTIVE', 'EXPIRING_SOON', 'EXPIRED', 'REVOKED'] as const).map((stat) => (
              <button
                key={stat}
                onClick={() => setStatusFilter(stat)}
                className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                  statusFilter === stat
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {stat === 'ALL'
                  ? 'All Statuses'
                  : stat === 'ACTIVE'
                  ? 'Active'
                  : stat === 'EXPIRING_SOON'
                  ? 'Expiring'
                  : stat === 'EXPIRED'
                  ? 'Expired'
                  : 'Revoked'}
              </button>
            ))}
          </div>

          {/* Blockchain Toggle Filter */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-[11px] text-slate-500 px-2 font-medium">Blockchain:</span>
            {(['ALL', 'ANCHORED', 'OFFCHAIN'] as const).map((bc) => (
              <button
                key={bc}
                onClick={() => setBlockchainFilter(bc)}
                className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                  blockchainFilter === bc
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {bc === 'ALL' ? 'All' : bc === 'ANCHORED' ? 'On-Chain Anchored' : 'Off-Chain Standard'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Credentials Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4 font-semibold">Credential ID</th>
                <th className="py-3 px-4 font-semibold">Candidate & Designation</th>
                <th className="py-3 px-4 font-semibold">Industry</th>
                <th className="py-3 px-4 font-semibold">Status & Expiration</th>
                <th className="py-3 px-4 font-semibold">Security Proof</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCredentials.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <div className="max-w-sm mx-auto space-y-2">
                      <p className="text-sm font-medium text-slate-300">No credentials matched current filters</p>
                      <p className="text-xs text-slate-500">
                        Try resetting your search query or industry filters to display records.
                      </p>
                      <button
                        onClick={() => {
                          setSearchQuery('');
                          setIndustryFilter('ALL');
                          setStatusFilter('ALL');
                          setBlockchainFilter('ALL');
                        }}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredCredentials.map((cert) => {
                  const status = computeCredentialStatus(cert);
                  const daysLeft = getDaysRemaining(cert.expirationDate);

                  return (
                    <tr
                      key={cert.id}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* ID & Hash */}
                      <td className="py-3 px-4 font-mono">
                        <div className="font-semibold text-white">{cert.id}</div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[140px]" title={cert.verificationHash}>
                          {cert.verificationHash.slice(0, 16)}...
                        </div>
                      </td>

                      {/* Recipient & Credential */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100 flex items-center gap-1.5">
                          <span>{cert.recipientName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({cert.recipientId})</span>
                        </div>
                        <div className="text-slate-300 text-[11px] font-medium line-clamp-1 max-w-xs">
                          {cert.credentialTitle}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {cert.issuingOrganization}
                        </div>
                      </td>

                      {/* Industry */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200">
                          {cert.industry === 'IT'
                            ? 'Information Tech'
                            : cert.industry === 'HEALTHCARE'
                            ? 'Healthcare'
                            : 'Skilled Trades'}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {cert.category}
                        </div>
                      </td>

                      {/* Status & Expiration */}
                      <td className="py-3 px-4">
                        {status === 'ACTIVE' && (
                          <div className="text-emerald-400 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Active</span>
                            <span className="text-slate-500 font-normal">({daysLeft}d left)</span>
                          </div>
                        )}
                        {status === 'EXPIRING_SOON' && (
                          <div className="text-amber-400 font-medium flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            <span>Expiring Soon</span>
                            <span className="text-slate-500 font-normal">({daysLeft}d left)</span>
                          </div>
                        )}
                        {status === 'EXPIRED' && (
                          <div className="text-red-400 font-medium flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Expired</span>
                          </div>
                        )}
                        {status === 'REVOKED' && (
                          <div className="text-red-500 font-medium flex items-center gap-1">
                            <Ban className="w-3.5 h-3.5" />
                            <span>Revoked</span>
                          </div>
                        )}
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          Exp: {cert.expirationDate}
                        </div>
                      </td>

                      {/* Security Proof */}
                      <td className="py-3 px-4">
                        {cert.blockchain.enabled ? (
                          <button
                            onClick={() => onOpenBlockchain(cert)}
                            className="inline-flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-mono hover:underline"
                            title="Inspect on-chain Merkle block proof"
                          >
                            <Blocks className="w-3.5 h-3.5 shrink-0" />
                            <span>{cert.blockchain.network?.split(' ')[0]} #{cert.blockchain.blockNumber}</span>
                          </button>
                        ) : (
                          <span className="text-slate-500 text-[11px]">Standard Digest</span>
                        )}
                        <div className="text-[10px] text-slate-400">
                          {cert.ceuCredits} CEU Hours
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Certificate View */}
                          <button
                            onClick={() => onOpenCertificate(cert)}
                            className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                            title="View Formal Certificate & Print"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Verify */}
                          <button
                            onClick={() => onOpenVerify(cert.id)}
                            className="p-1.5 text-blue-400 hover:text-blue-300 bg-blue-950/60 hover:bg-blue-900/60 rounded transition-colors"
                            title="Verify Cryptographic Proof"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                          </button>

                          {/* Renew (only if not revoked) */}
                          {status !== 'REVOKED' && (
                            <button
                              onClick={() => onOpenRenewal(cert)}
                              className="p-1.5 text-emerald-400 hover:text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 rounded transition-colors"
                              title="Process Renewal & Log CEUs"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Revoke (if active or expiring) */}
                          {status !== 'REVOKED' && (
                            <button
                              onClick={() => onOpenRevoke(cert)}
                              className="p-1.5 text-red-400 hover:text-red-300 bg-red-950/60 hover:bg-red-900/60 rounded transition-colors"
                              title="Administrative Revocation"
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Count */}
        <div className="px-4 py-2.5 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing <span className="font-semibold text-white">{filteredCredentials.length}</span> of{' '}
            <span className="font-semibold text-white">{credentials.length}</span> credentials in registry
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            Compliant with ISO/IEC 17024 and W3C Verifiable Credentials
          </div>
        </div>
      </div>
    </div>
  );
};
