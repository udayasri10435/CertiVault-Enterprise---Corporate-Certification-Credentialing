import React, { useMemo } from 'react';
import { Certification, Industry } from '../types/credential';
import { computeCredentialStatus, getDaysRemaining } from '../utils/crypto';
import {
  Award,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Blocks,
  Cpu,
  HeartPulse,
  Wrench,
  CheckCircle2,
  RefreshCw,
  Eye,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

interface DashboardViewProps {
  credentials: Certification[];
  onNavigateToLedger: (industry?: Industry) => void;
  onOpenIssue: () => void;
  onOpenCertificate: (cert: Certification) => void;
  onOpenRenewal: (cert: Certification) => void;
  onOpenVerify: (certId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  credentials,
  onNavigateToLedger,
  onOpenIssue,
  onOpenCertificate,
  onOpenRenewal,
  onOpenVerify,
}) => {
  // Aggregate statistics
  const stats = useMemo(() => {
    let active = 0;
    let expiringSoon = 0;
    let expired = 0;
    let revoked = 0;
    let blockchainAnchored = 0;

    const byIndustry: Record<Industry, { total: number; active: number; expiring: number; expired: number }> = {
      IT: { total: 0, active: 0, expiring: 0, expired: 0 },
      HEALTHCARE: { total: 0, active: 0, expiring: 0, expired: 0 },
      TRADES: { total: 0, active: 0, expiring: 0, expired: 0 },
    };

    credentials.forEach((c) => {
      const status = computeCredentialStatus(c);
      if (status === 'ACTIVE') active++;
      else if (status === 'EXPIRING_SOON') expiringSoon++;
      else if (status === 'EXPIRED') expired++;
      else if (status === 'REVOKED') revoked++;

      if (c.blockchain.enabled) blockchainAnchored++;

      byIndustry[c.industry].total++;
      if (status === 'ACTIVE') byIndustry[c.industry].active++;
      else if (status === 'EXPIRING_SOON') byIndustry[c.industry].expiring++;
      else if (status === 'EXPIRED') byIndustry[c.industry].expired++;
    });

    const activeComplianceRate = credentials.length > 0 ? Math.round(((active + expiringSoon) / credentials.length) * 100) : 0;

    return {
      total: credentials.length,
      active,
      expiringSoon,
      expired,
      revoked,
      blockchainAnchored,
      activeComplianceRate,
      byIndustry,
    };
  }, [credentials]);

  // Expiration watchlist (sorted by soonest to expire)
  const expiringWatchlist = useMemo(() => {
    return credentials
      .filter((c) => computeCredentialStatus(c) === 'EXPIRING_SOON')
      .sort((a, b) => new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime());
  }, [credentials]);

  return (
    <div className="space-y-6">
      {/* Top Welcome / Hero Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-1">
            <span>Corporate Accreditation Oversight</span>
            <span aria-hidden="true">·</span>
            <span>Real-time Compliance Engine</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Certification & Credentialing Administration
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
            Manage the issuance, cryptographic verification, and lifecycle renewal of accredited workforce credentials
            across Information Technology, Healthcare, and Skilled Trades.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => onOpenVerify()}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span>Verify Portal</span>
          </button>
          <button
            onClick={onOpenIssue}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition-colors shadow-xs flex items-center gap-1.5"
          >
            <Award className="w-4 h-4" />
            <span>+ Issue Credential</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Credentials */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-medium">Total Credentials</span>
            <Award className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white tabular-nums">
            {stats.total}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Accredited workforce roster
          </div>
        </div>

        {/* Active & Compliant */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-medium">Active & In Good Standing</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-emerald-400 tabular-nums">
            {stats.active}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {stats.activeComplianceRate}% workforce compliance rate
          </div>
        </div>

        {/* Expiring Soon */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-medium">Renewal Window Open</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-amber-400 tabular-nums">
            {stats.expiringSoon}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Expiring within 60 days
          </div>
        </div>

        {/* Blockchain Anchored */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-medium">On-Chain Anchored</span>
            <Blocks className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-indigo-300 tabular-nums">
            {stats.blockchainAnchored}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {Math.round((stats.blockchainAnchored / (stats.total || 1)) * 100)}% immutable ledger proofs
          </div>
        </div>
      </div>

      {/* Industry Sector Breakdown */}
      <div>
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Accreditation Sectors
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* IT & Cloud */}
          <div
            onClick={() => onNavigateToLedger('IT')}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 cursor-pointer transition-all hover:bg-slate-800/50 group"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-950/80 border border-blue-800/80 rounded-lg text-blue-400">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm group-hover:text-blue-300 transition-colors">
                    Information Technology
                  </h3>
                  <div className="text-[11px] text-slate-400">Cloud, DevOps & Cyber Defense</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-center">
              <div>
                <div className="text-base font-bold text-white tabular-nums">
                  {stats.byIndustry.IT.total}
                </div>
                <div className="text-[10px] text-slate-400">Total</div>
              </div>
              <div>
                <div className="text-base font-bold text-emerald-400 tabular-nums">
                  {stats.byIndustry.IT.active}
                </div>
                <div className="text-[10px] text-slate-400">Active</div>
              </div>
              <div>
                <div className="text-base font-bold text-amber-400 tabular-nums">
                  {stats.byIndustry.IT.expiring}
                </div>
                <div className="text-[10px] text-slate-400">Expiring</div>
              </div>
            </div>
          </div>

          {/* Healthcare & Clinical */}
          <div
            onClick={() => onNavigateToLedger('HEALTHCARE')}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 cursor-pointer transition-all hover:bg-slate-800/50 group"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-950/80 border border-emerald-800/80 rounded-lg text-emerald-400">
                  <HeartPulse className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm group-hover:text-emerald-300 transition-colors">
                    Healthcare & Clinical
                  </h3>
                  <div className="text-[11px] text-slate-400">ACLS, HIPAA & Infection Control</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-center">
              <div>
                <div className="text-base font-bold text-white tabular-nums">
                  {stats.byIndustry.HEALTHCARE.total}
                </div>
                <div className="text-[10px] text-slate-400">Total</div>
              </div>
              <div>
                <div className="text-base font-bold text-emerald-400 tabular-nums">
                  {stats.byIndustry.HEALTHCARE.active}
                </div>
                <div className="text-[10px] text-slate-400">Active</div>
              </div>
              <div>
                <div className="text-base font-bold text-amber-400 tabular-nums">
                  {stats.byIndustry.HEALTHCARE.expiring}
                </div>
                <div className="text-[10px] text-slate-400">Expiring</div>
              </div>
            </div>
          </div>

          {/* Skilled Trades */}
          <div
            onClick={() => onNavigateToLedger('TRADES')}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 cursor-pointer transition-all hover:bg-slate-800/50 group"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-950/80 border border-amber-800/80 rounded-lg text-amber-400">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm group-hover:text-amber-300 transition-colors">
                    Skilled Trades & Safety
                  </h3>
                  <div className="text-[11px] text-slate-400">Electrician, OSHA 30 & HVAC/R</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-center">
              <div>
                <div className="text-base font-bold text-white tabular-nums">
                  {stats.byIndustry.TRADES.total}
                </div>
                <div className="text-[10px] text-slate-400">Total</div>
              </div>
              <div>
                <div className="text-base font-bold text-emerald-400 tabular-nums">
                  {stats.byIndustry.TRADES.active}
                </div>
                <div className="text-[10px] text-slate-400">Active</div>
              </div>
              <div>
                <div className="text-base font-bold text-amber-400 tabular-nums">
                  {stats.byIndustry.TRADES.expiring}
                </div>
                <div className="text-[10px] text-slate-400">Expiring</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Expiration Watchlist & Action Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 bg-slate-950/50 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-semibold text-white tracking-tight">
              Active Expiration Watchlist (Within 60-Day Renewal Window)
            </h2>
          </div>
          <button
            onClick={() => onNavigateToLedger()}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
          >
            <span>View All in Ledger</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {expiringWatchlist.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            <CheckCircle2 className="w-8 h-8 text-emerald-500/80 mx-auto mb-2" />
            <p className="text-slate-300 font-medium">All credentials in compliance</p>
            <p className="text-slate-500">No workforce certifications are currently in the 60-day expiration window.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60">
            {expiringWatchlist.map((cert) => {
              const daysLeft = getDaysRemaining(cert.expirationDate);
              return (
                <div
                  key={cert.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-800/30 transition-colors"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white">{cert.recipientName}</span>
                      <span className="text-[10px] text-slate-500 font-mono">({cert.recipientId})</span>
                      <span className="text-[10px] text-slate-400">· {cert.industry}</span>
                    </div>
                    <div className="text-xs text-slate-300 font-medium">
                      {cert.credentialTitle}
                    </div>
                    <div className="text-[11px] text-amber-400 font-mono">
                      Expires: {cert.expirationDate} ({daysLeft} days remaining)
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onOpenCertificate(cert)}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Certificate</span>
                    </button>
                    <button
                      onClick={() => onOpenRenewal(cert)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-medium transition-colors flex items-center gap-1 shadow-xs"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Process Renewal</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Enterprise Architecture Explainer */}
      <div className="p-5 bg-slate-900/60 border border-slate-800/80 rounded-xl grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300">
        <div>
          <div className="text-white font-semibold flex items-center gap-2 mb-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>ISO/IEC 17024 Standard</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Strict adherence to conformity assessments for personnel certification bodies,
            preserving structured competency matrices and verifiable CEU credit hours.
          </p>
        </div>

        <div>
          <div className="text-white font-semibold flex items-center gap-2 mb-1.5">
            <Blocks className="w-4 h-4 text-indigo-400" />
            <span>Blockchain-Optional Anchoring</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Choose standard SHA-256 digital seals for internal audits, or publish decentralized Merkle roots
            to Polygon/Ethereum for immutable cross-enterprise proof.
          </p>
        </div>

        <div>
          <div className="text-white font-semibold flex items-center gap-2 mb-1.5">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Automated Lifecycle Governance</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Dynamic expiration threshold calculations, instant administrative revocation audit trails,
            and seamless continuing education credit extensions.
          </p>
        </div>
      </div>
    </div>
  );
};
