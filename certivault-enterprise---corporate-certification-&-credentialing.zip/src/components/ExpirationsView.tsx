import React, { useState, useMemo } from 'react';
import { Certification, Industry } from '../types/credential';
import { computeCredentialStatus, getDaysRemaining } from '../utils/crypto';
import {
  Clock,
  AlertTriangle,
  RefreshCw,
  Mail,
  CheckCircle2,
  Filter,
  Calendar,
  Eye,
  ShieldAlert,
} from 'lucide-react';

interface ExpirationsViewProps {
  credentials: Certification[];
  onOpenRenewal: (cert: Certification) => void;
  onOpenCertificate: (cert: Certification) => void;
}

export const ExpirationsView: React.FC<ExpirationsViewProps> = ({
  credentials,
  onOpenRenewal,
  onOpenCertificate,
}) => {
  const [horizonFilter, setHorizonFilter] = useState<'30' | '60' | '90' | 'ALL'>('60');
  const [industryFilter, setIndustryFilter] = useState<'ALL' | Industry>('ALL');
  const [notificationSentMessage, setNotificationSentMessage] = useState<string | null>(null);

  // Filter credentials with expiration focus
  const items = useMemo(() => {
    return credentials
      .filter((c) => {
        if (industryFilter !== 'ALL' && c.industry !== industryFilter) return false;
        const status = computeCredentialStatus(c);
        const days = getDaysRemaining(c.expirationDate);

        if (horizonFilter === '30') return days <= 30 && status !== 'REVOKED';
        if (horizonFilter === '60') return days <= 60 && status !== 'REVOKED';
        if (horizonFilter === '90') return days <= 90 && status !== 'REVOKED';
        return status === 'EXPIRING_SOON' || status === 'EXPIRED';
      })
      .sort((a, b) => new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime());
  }, [credentials, horizonFilter, industryFilter]);

  const handleSendReminders = () => {
    setNotificationSentMessage(`Automated recertification compliance reminders dispatched to ${items.length} candidate inboxes.`);
    setTimeout(() => {
      setNotificationSentMessage(null);
    }, 4000);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs uppercase tracking-wider mb-1">
            <Clock className="w-4 h-4" />
            <span>Lifecycle Expiration & Recertification Hub</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Workforce Compliance & Expiration Governance
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
            Monitor approaching credential expirations across IT, Healthcare, and Skilled Trades.
            Authorize renewals, record CEUs, and avert compliance lapses before statutory deadlines.
          </p>
        </div>

        <button
          onClick={handleSendReminders}
          disabled={items.length === 0}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
        >
          <Mail className="w-4 h-4" />
          <span>Dispatch Renewal Notices ({items.length})</span>
        </button>
      </div>

      {notificationSentMessage && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-200 rounded-lg text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notificationSentMessage}</span>
        </div>
      )}

      {/* Filter Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs">
        {/* Horizon Filter */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-500 px-2 font-medium">Time Horizon:</span>
          <button
            onClick={() => setHorizonFilter('30')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              horizonFilter === '30' ? 'bg-slate-800 text-amber-300 shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ≤ 30 Days (Urgent)
          </button>
          <button
            onClick={() => setHorizonFilter('60')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              horizonFilter === '60' ? 'bg-slate-800 text-amber-300 shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ≤ 60 Days (Standard)
          </button>
          <button
            onClick={() => setHorizonFilter('90')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              horizonFilter === '90' ? 'bg-slate-800 text-amber-300 shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ≤ 90 Days (Advance)
          </button>
          <button
            onClick={() => setHorizonFilter('ALL')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              horizonFilter === 'ALL' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Lapses & Expired
          </button>
        </div>

        {/* Sector Filter */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-500 px-2 font-medium">Industry:</span>
          {(['ALL', 'IT', 'HEALTHCARE', 'TRADES'] as const).map((ind) => (
            <button
              key={ind}
              onClick={() => setIndustryFilter(ind)}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                industryFilter === ind ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {ind === 'ALL' ? 'All' : ind === 'IT' ? 'IT' : ind === 'HEALTHCARE' ? 'Healthcare' : 'Trades'}
            </button>
          ))}
        </div>
      </div>

      {/* Expirations Grid Cards */}
      {items.length === 0 ? (
        <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-xl">
          <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
          <h3 className="text-sm font-semibold text-white">No Credentials In Danger of Expiration</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            All certifications under the selected criteria are active and compliant beyond the chosen threshold.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((cert) => {
            const status = computeCredentialStatus(cert);
            const daysLeft = getDaysRemaining(cert.expirationDate);
            const isLapsed = daysLeft <= 0;

            return (
              <div
                key={cert.id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition-colors space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-mono text-slate-400">{cert.id}</span>
                    <span
                      className={`text-[11px] font-semibold flex items-center gap-1 ${
                        isLapsed ? 'text-red-400' : 'text-amber-400'
                      }`}
                    >
                      {isLapsed ? (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Lapsed ({Math.abs(daysLeft)}d ago)</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3.5 h-3.5" />
                          <span>{daysLeft} Days Left</span>
                        </>
                      )}
                    </span>
                  </div>

                  <h3 className="font-semibold text-white text-sm line-clamp-1">
                    {cert.recipientName}
                  </h3>
                  <div className="text-slate-300 text-xs font-medium line-clamp-1 mt-0.5">
                    {cert.credentialTitle}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {cert.industry} · {cert.recipientEmail}
                  </div>

                  {/* Continuing Education / Expiration Info */}
                  <div className="mt-3 p-2 bg-slate-950/80 rounded border border-slate-800 text-[11px] space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Expiration Date:</span>
                      <span className="font-mono text-slate-200">{cert.expirationDate}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Accreditation Hours:</span>
                      <span className="font-semibold text-slate-200">{cert.ceuCredits} CEU Hours</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onOpenCertificate(cert)}
                    className="px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Cert</span>
                  </button>

                  <button
                    onClick={() => onOpenRenewal(cert)}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Renew Now</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
