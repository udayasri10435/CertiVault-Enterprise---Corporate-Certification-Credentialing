import React from 'react';

interface GuillocheBorderProps {
  theme?: 'classic_navy' | 'emerald_clinical' | 'amber_industrial' | 'modern_dark';
}

export const GuillocheBorder: React.FC<GuillocheBorderProps> = ({ theme = 'classic_navy' }) => {
  const getStrokeColors = () => {
    switch (theme) {
      case 'emerald_clinical':
        return { primary: '#059669', gold: '#d97706', subtle: '#a7f3d0' };
      case 'amber_industrial':
        return { primary: '#b45309', gold: '#d97706', subtle: '#fde68a' };
      case 'modern_dark':
        return { primary: '#2563eb', gold: '#94a3b8', subtle: '#cbd5e1' };
      case 'classic_navy':
      default:
        return { primary: '#1e3a8a', gold: '#d97706', subtle: '#bfdbfe' };
    }
  };

  const colors = getStrokeColors();

  return (
    <div className="absolute inset-0 pointer-events-none p-3 sm:p-5 select-none">
      {/* Outer Border Box */}
      <div
        className="w-full h-full relative"
        style={{
          border: `2px solid ${colors.gold}`,
          padding: '6px',
        }}
      >
        {/* Inner Border Box */}
        <div
          className="w-full h-full relative"
          style={{
            border: `1px solid ${colors.primary}`,
          }}
        >
          {/* Corner Rosette Ornaments */}
          {/* Top Left */}
          <svg className="absolute -top-[14px] -left-[14px] w-7 h-7" viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="14" fill="#ffffff" stroke={colors.gold} strokeWidth="1.5" />
            <circle cx="20" cy="20" r="8" fill="none" stroke={colors.primary} strokeWidth="1" strokeDasharray="2,2" />
            <circle cx="20" cy="20" r="3" fill={colors.gold} />
          </svg>

          {/* Top Right */}
          <svg className="absolute -top-[14px] -right-[14px] w-7 h-7" viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="14" fill="#ffffff" stroke={colors.gold} strokeWidth="1.5" />
            <circle cx="20" cy="20" r="8" fill="none" stroke={colors.primary} strokeWidth="1" strokeDasharray="2,2" />
            <circle cx="20" cy="20" r="3" fill={colors.gold} />
          </svg>

          {/* Bottom Left */}
          <svg className="absolute -bottom-[14px] -left-[14px] w-7 h-7" viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="14" fill="#ffffff" stroke={colors.gold} strokeWidth="1.5" />
            <circle cx="20" cy="20" r="8" fill="none" stroke={colors.primary} strokeWidth="1" strokeDasharray="2,2" />
            <circle cx="20" cy="20" r="3" fill={colors.gold} />
          </svg>

          {/* Bottom Right */}
          <svg className="absolute -bottom-[14px] -right-[14px] w-7 h-7" viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="14" fill="#ffffff" stroke={colors.gold} strokeWidth="1.5" />
            <circle cx="20" cy="20" r="8" fill="none" stroke={colors.primary} strokeWidth="1" strokeDasharray="2,2" />
            <circle cx="20" cy="20" r="3" fill={colors.gold} />
          </svg>
        </div>
      </div>
    </div>
  );
};
