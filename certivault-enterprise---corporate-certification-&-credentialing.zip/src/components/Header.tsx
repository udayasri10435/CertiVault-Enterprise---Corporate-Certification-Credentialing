import React from 'react';
import { Award, ShieldCheck } from 'lucide-react';

export type ActiveView = 'dashboard' | 'ledger' | 'verification' | 'expirations';

interface HeaderProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  onOpenIssue: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  onOpenIssue,
}) => {
  return (
    <header className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 no-print">
      {/* Zone 1: Single text element wordmark */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          setActiveView('dashboard');
        }}
        className="text-lg font-bold tracking-tight text-white hover:text-indigo-400 transition-colors whitespace-nowrap"
      >
        CertiVault Enterprise
      </a>

      {/* Zone 2: 4 clean navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
        <button
          onClick={() => setActiveView('dashboard')}
          className={`transition-colors whitespace-nowrap ${
            activeView === 'dashboard'
              ? 'text-white font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => setActiveView('ledger')}
          className={`transition-colors whitespace-nowrap ${
            activeView === 'ledger'
              ? 'text-white font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Credentials
        </button>
        <button
          onClick={() => setActiveView('expirations')}
          className={`transition-colors whitespace-nowrap ${
            activeView === 'expirations'
              ? 'text-white font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Expirations
        </button>
        <button
          onClick={() => setActiveView('verification')}
          className={`transition-colors whitespace-nowrap ${
            activeView === 'verification'
              ? 'text-white font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Verification
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={() => setActiveView('verification')}
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span>Verify Portal</span>
        </button>

        <button
          onClick={onOpenIssue}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shadow-xs"
        >
          <Award className="w-3.5 h-3.5" />
          <span>+ Issue Credential</span>
        </button>
      </div>
    </header>
  );
};
