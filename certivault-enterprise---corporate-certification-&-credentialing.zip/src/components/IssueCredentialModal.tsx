import React, { useState } from 'react';
import { Certification, Industry, CertificateTheme, BlockchainAnchor } from '../types/credential';
import { INDUSTRY_TEMPLATES } from '../data/initialCredentials';
import {
  generateCredentialId,
  getCanonicalCredentialPayload,
  calculateSHA256,
  generateBlockchainAnchor,
} from '../utils/crypto';
import { X, Award, Blocks, Users, FileText, CheckCircle2, Sparkles } from 'lucide-react';

interface IssueCredentialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onIssued: (newCerts: Certification[]) => void;
}

export const IssueCredentialModal: React.FC<IssueCredentialModalProps> = ({
  isOpen,
  onClose,
  onIssued,
}) => {
  const [activeTab, setActiveTab] = useState<'single' | 'batch'>('single');

  // Single form states
  const [industry, setIndustry] = useState<Industry>('IT');
  const [recipientName, setRecipientName] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [recipientId, setRecipientId] = useState(`EMP-${Math.floor(10000 + Math.random() * 90000)}`);
  const [credentialTitle, setCredentialTitle] = useState('Certified Cloud Solutions Architect - Enterprise Tier');
  const [category, setCategory] = useState('Cloud Infrastructure & Architecture');
  const [issuingOrganization, setIssuingOrganization] = useState('Apex Global Cloud Academy & ISO 17024 Registry');
  const [signerName, setSignerName] = useState('Elena Rostova, Ph.D.');
  const [signerTitle, setSignerTitle] = useState('Dean of Technology Certification');
  const [validityMonths, setValidityMonths] = useState(36);
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);
  const [competencies, setCompetencies] = useState<string[]>([
    'Multi-Region Resilient Topology',
    'Zero-Trust VPC Peering & IAM Federation',
    'Microservices Orchestration',
    'FinOps Cost Governance'
  ]);
  const [newCompetencyInput, setNewCompetencyInput] = useState('');
  const [ceuCredits, setCeuCredits] = useState<number>(40);
  const [scorePercent, setScorePercent] = useState<number>(95);
  const [theme, setTheme] = useState<CertificateTheme>('modern_dark');
  const [blockchainEnabled, setBlockchainEnabled] = useState(true);
  const [blockchainNetwork, setBlockchainNetwork] = useState<'Polygon PoS Enterprise' | 'Ethereum Mainnet Anchor' | 'Hyperledger Besu Consortia'>('Polygon PoS Enterprise');

  // Batch form states
  const [batchData, setBatchData] = useState(`Alex Mercer, a.mercer@corporate.com, EMP-51001\nElena Gomez, e.gomez@corporate.com, EMP-51002\nRajesh Patel, r.patel@corporate.com, EMP-51003`);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  // Handle template selection
  const handleSelectTemplate = (templateTitle: string) => {
    const template = INDUSTRY_TEMPLATES.find((t) => t.title === templateTitle);
    if (!template) return;

    setIndustry(template.industry);
    setCredentialTitle(template.title);
    setCategory(template.category);
    setValidityMonths(template.defaultValidityMonths);
    setCeuCredits(template.defaultCeu);
    setCompetencies([...template.competencies]);
    setTheme(template.suggestedTheme);

    if (template.industry === 'IT') {
      setIssuingOrganization('Apex Global Cloud Academy & ISO 17024 Registry');
      setSignerName('Elena Rostova, Ph.D.');
      setSignerTitle('Dean of Technology Certification');
    } else if (template.industry === 'HEALTHCARE') {
      setIssuingOrganization('St. Jude Clinical Medical Board & Resuscitation Academy');
      setSignerName('Dr. Anthony M. Mercer, MD, FACC');
      setSignerTitle('Chair of Clinical Resuscitation');
    } else {
      setIssuingOrganization('National Trades & Safety Certification Council');
      setSignerName('Master Inspector Harold J. Briggs');
      setSignerTitle('Chief Electrical Examiner & NFPA Trustee');
    }
  };

  const handleAddCompetency = () => {
    if (newCompetencyInput.trim() && !competencies.includes(newCompetencyInput.trim())) {
      setCompetencies([...competencies, newCompetencyInput.trim()]);
      setNewCompetencyInput('');
    }
  };

  const handleRemoveCompetency = (index: number) => {
    setCompetencies(competencies.filter((_, i) => i !== index));
  };

  // Compute calculated expiration date
  const computeExpirationDate = (issueDateStr: string, months: number) => {
    const d = new Date(issueDateStr);
    d.setMonth(d.getMonth() + months);
    return d.toISOString().split('T')[0];
  };

  const currentExpirationDate = computeExpirationDate(issueDate, validityMonths);

  const handleSingleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    const certId = generateCredentialId(industry);
    const expirationDate = currentExpirationDate;

    const draftCert: Partial<Certification> = {
      id: certId,
      credentialTitle,
      recipientName,
      recipientEmail,
      recipientId,
      industry,
      category,
      issuingOrganization,
      authorizedSigner: {
        name: signerName,
        title: signerTitle,
        signatureText: signerName,
      },
      issueDate,
      expirationDate,
      competencies,
      ceuCredits: Number(ceuCredits),
      blockchain: { enabled: blockchainEnabled },
    };

    const canonicalPayload = getCanonicalCredentialPayload(draftCert);
    const verificationHash = await calculateSHA256(canonicalPayload);

    let blockchainRecord: BlockchainAnchor = { enabled: false };
    if (blockchainEnabled) {
      blockchainRecord = {
        ...generateBlockchainAnchor(certId, verificationHash),
        network: blockchainNetwork,
      };
    }

    const finalCert: Certification = {
      ...draftCert as any,
      id: certId,
      status: 'ACTIVE',
      verificationHash,
      blockchain: blockchainRecord as any,
      metadata: {
        accreditationStandard: 'ISO/IEC 17024 Accredited Standard',
        scorePercent: Number(scorePercent),
        certificateTheme: theme,
        gradeLevel: scorePercent >= 95 ? 'High Honors / Lead' : 'Standard Certification',
      },
      renewalHistory: [],
    };

    onIssued([finalCert]);
    setIsProcessing(false);
    onClose();
  };

  const handleBatchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    const lines = batchData.split('\n').filter(l => l.trim().length > 0);
    const createdCerts: Certification[] = [];

    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split(',').map(p => p.trim());
      const name = parts[0] || `Candidate ${i + 1}`;
      const email = parts[1] || `user${i + 1}@enterprise.com`;
      const empId = parts[2] || `EMP-${Math.floor(10000 + Math.random() * 90000)}`;

      const certId = generateCredentialId(industry);
      const expirationDate = currentExpirationDate;

      const draftCert: Partial<Certification> = {
        id: certId,
        credentialTitle,
        recipientName: name,
        recipientEmail: email,
        recipientId: empId,
        industry,
        category,
        issuingOrganization,
        authorizedSigner: {
          name: signerName,
          title: signerTitle,
          signatureText: signerName,
        },
        issueDate,
        expirationDate,
        competencies,
        ceuCredits: Number(ceuCredits),
        blockchain: { enabled: blockchainEnabled },
      };

      const canonicalPayload = getCanonicalCredentialPayload(draftCert);
      const verificationHash = await calculateSHA256(canonicalPayload);

      let blockchainRecord: BlockchainAnchor = { enabled: false };
      if (blockchainEnabled) {
        blockchainRecord = {
          ...generateBlockchainAnchor(certId, verificationHash),
          network: blockchainNetwork,
        };
      }

      createdCerts.push({
        ...draftCert as any,
        id: certId,
        status: 'ACTIVE',
        verificationHash,
        blockchain: blockchainRecord as any,
        metadata: {
          accreditationStandard: 'ISO/IEC 17024 Enterprise Accredited Standard',
          scorePercent: 92,
          certificateTheme: theme,
        },
        renewalHistory: [],
      });
    }

    onIssued(createdCerts);
    setIsProcessing(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 text-slate-100">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-3xl w-full flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/95 shrink-0">
          <div className="flex items-center gap-2.5">
            <Award className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-semibold text-white tracking-tight">
                Issue Corporate Certification
              </h2>
              <p className="text-xs text-slate-400">
                Generate cryptographically signed credential with optional blockchain anchoring
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="flex border-b border-slate-800 px-6 bg-slate-950/40 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('single')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'single'
                ? 'border-indigo-500 text-white bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Single Credential</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('batch')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'batch'
                ? 'border-indigo-500 text-white bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Batch Multi-Candidate Issuance</span>
          </button>
        </div>

        {/* Body Form */}
        <div className="overflow-y-auto p-6 space-y-5 text-xs">
          {/* Preset Template Selector */}
          <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg">
            <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Standard Accredited Industry Templates</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {['IT', 'HEALTHCARE', 'TRADES'].map((ind) => (
                <div key={ind} className="space-y-1">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    {ind === 'IT' ? 'Information Tech' : ind === 'HEALTHCARE' ? 'Clinical Healthcare' : 'Skilled Trades'}
                  </div>
                  {INDUSTRY_TEMPLATES.filter((t) => t.industry === ind).map((t) => (
                    <button
                      key={t.title}
                      type="button"
                      onClick={() => handleSelectTemplate(t.title)}
                      className={`w-full text-left p-2 rounded text-[11px] border transition-colors leading-tight ${
                        credentialTitle === t.title
                          ? 'bg-indigo-950/70 border-indigo-500/80 text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-medium truncate">{t.title}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{t.defaultValidityMonths}mo validity · {t.defaultCeu} CEU</div>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </div>

          {activeTab === 'single' ? (
            <form onSubmit={handleSingleSubmit} id="single-issue-form" className="space-y-4">
              {/* Recipient Information */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Candidate Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jordan Miller, PE"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Candidate Work Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="j.miller@enterprise.com"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Employee / Candidate ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={recipientId}
                    onChange={(e) => setRecipientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              {/* Title & Organization */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Credential Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={credentialTitle}
                    onChange={(e) => setCredentialTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Domain Category
                  </label>
                  <input
                    type="text"
                    required
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Issuing Authority & Signer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Issuing Organization / Board
                  </label>
                  <input
                    type="text"
                    required
                    value={issuingOrganization}
                    onChange={(e) => setIssuingOrganization(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Authorized Signer & Title
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      placeholder="Name"
                      value={signerName}
                      onChange={(e) => setSignerName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Title"
                      value={signerTitle}
                      onChange={(e) => setSignerTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Dates & Validity Calculation */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 bg-slate-950/70 border border-slate-800 rounded-lg items-center">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">
                    Issue Date
                  </label>
                  <input
                    type="date"
                    required
                    value={issueDate}
                    onChange={(e) => setIssueDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">
                    Validity Duration
                  </label>
                  <select
                    value={validityMonths}
                    onChange={(e) => setValidityMonths(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 text-[11px]"
                  >
                    <option value={12}>1 Year (12 months)</option>
                    <option value={24}>2 Years (24 months)</option>
                    <option value={36}>3 Years (36 months)</option>
                    <option value={60}>5 Years (60 months)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">
                    Calculated Expiration
                  </label>
                  <div className="font-mono text-emerald-400 font-semibold px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded text-[11px]">
                    {currentExpirationDate}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">
                    CEU Hours / Score
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min={0}
                      max={120}
                      value={ceuCredits}
                      onChange={(e) => setCeuCredits(Number(e.target.value))}
                      className="w-1/2 bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-slate-200 tabular-nums text-[11px]"
                      placeholder="CEU"
                    />
                    <input
                      type="number"
                      min={60}
                      max={100}
                      value={scorePercent}
                      onChange={(e) => setScorePercent(Number(e.target.value))}
                      className="w-1/2 bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-slate-200 tabular-nums text-[11px]"
                      placeholder="Score %"
                    />
                  </div>
                </div>
              </div>

              {/* Competencies */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Verified Competencies ({competencies.length})
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    placeholder="Add specific mastery / regulation skill..."
                    value={newCompetencyInput}
                    onChange={(e) => setNewCompetencyInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCompetency();
                      }
                    }}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-slate-200"
                  />
                  <button
                    type="button"
                    onClick={handleAddCompetency}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors font-medium"
                  >
                    + Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                  {competencies.map((comp, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/80 border border-slate-700 text-slate-300 rounded text-[11px]"
                    >
                      <span>{comp}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveCompetency(idx)}
                        className="text-slate-400 hover:text-red-400"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Visual Theme & Blockchain-Optional Anchor */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Certificate Theme
                  </label>
                  <select
                    value={theme}
                    onChange={(e) => setTheme(e.target.value as CertificateTheme)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200"
                  >
                    <option value="modern_dark">Tech Modern Dark / Slate</option>
                    <option value="classic_navy">Classic Corporate Navy & Gold</option>
                    <option value="emerald_clinical">Healthcare Clinical Emerald</option>
                    <option value="amber_industrial">Skilled Trades Industrial Amber</option>
                  </select>
                </div>

                {/* Blockchain-Optional Control */}
                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                      <Blocks className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Blockchain Anchor</span>
                    </span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={blockchainEnabled}
                        onChange={(e) => setBlockchainEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>

                  {blockchainEnabled ? (
                    <div className="space-y-1.5 text-[11px]">
                      <select
                        value={blockchainNetwork}
                        onChange={(e) => setBlockchainNetwork(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 text-[11px]"
                      >
                        <option value="Polygon PoS Enterprise">Polygon PoS Enterprise</option>
                        <option value="Ethereum Mainnet Anchor">Ethereum Mainnet Anchor</option>
                        <option value="Hyperledger Besu Consortia">Hyperledger Besu Consortia</option>
                      </select>
                      <div className="text-emerald-400 text-[10px]">
                        ✓ Merkle root digest will be anchored to smart contract registry upon issuance.
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-400 text-[10px]">
                      Standard SHA-256 digital signature without on-chain ledger publication.
                    </div>
                  )}
                </div>
              </div>
            </form>
          ) : (
            /* Batch Multi-Candidate Mode */
            <form onSubmit={handleBatchSubmit} id="batch-issue-form" className="space-y-4">
              <div className="p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-lg text-slate-300 text-xs">
                <div className="font-semibold text-indigo-300 mb-1">Batch Candidate Ingestion (CSV / Multiline)</div>
                <p>
                  Paste candidate records format: <code className="text-white font-mono">Full Name, Work Email, Employee ID</code> (one per line).
                  All candidates will be issued the currently selected credential template ({credentialTitle}).
                </p>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Candidate Roster Data
                </label>
                <textarea
                  rows={6}
                  required
                  value={batchData}
                  onChange={(e) => setBatchData(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 font-mono text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-slate-200 font-medium">Batch Blockchain Anchoring</div>
                  <div className="text-[11px] text-slate-400">
                    Group batch into a single Merkle tree proof root ({blockchainNetwork})
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={blockchainEnabled}
                    onChange={(e) => setBlockchainEnabled(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </form>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-400">
            {activeTab === 'single'
              ? 'SHA-256 Web Crypto Signature will be computed deterministically.'
              : `${batchData.split('\n').filter(l => l.trim().length > 0).length} candidates detected in roster.`}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              form={activeTab === 'single' ? 'single-issue-form' : 'batch-issue-form'}
              disabled={isProcessing || (activeTab === 'single' && !recipientName)}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg font-medium transition-colors flex items-center gap-1.5"
            >
              {isProcessing ? (
                <span>Generating Cryptographic Proofs...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{activeTab === 'single' ? 'Issue & Mint Credential' : 'Batch Mint All Records'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
