import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface QRCodeDisplayProps {
  value: string;
  size?: number;
  className?: string;
}

export const QRCodeDisplay: React.FC<QRCodeDisplayProps> = ({
  value,
  size = 96,
  className = '',
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(value, {
      width: size * 2,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url: string) => {
        if (isMounted) setQrDataUrl(url);
      })
      .catch((err: unknown) => {
        console.error('QR code generation error:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [value, size]);

  if (!qrDataUrl) {
    return (
      <div
        className={`bg-slate-100 flex items-center justify-center text-[10px] text-slate-400 font-mono ${className}`}
        style={{ width: size, height: size }}
      >
        QR
      </div>
    );
  }

  return (
    <img
      src={qrDataUrl}
      alt={`Verification QR Code for ${value}`}
      className={`border border-slate-200 bg-white p-0.5 rounded-sm shadow-xs ${className}`}
      style={{ width: size, height: size }}
    />
  );
};
