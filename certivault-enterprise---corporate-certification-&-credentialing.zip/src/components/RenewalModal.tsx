import React, { useState } from 'react';
import { Certification } from '../types/credential';
import { X, RefreshCw, Calendar, Award, UserCheck } from 'lucide-react';

interface RenewalModalProps {
  cert: Certification | null;
  onClose: () => void;
  onRenew: (certId: string, renewalData: {
    newExpiration: string;
    ceuSubmitted: number;
    authorizedBy: string;
    notes: string;
  }) => void;
}

export const RenewalModal: React.FC<RenewalModalProps> = ({ cert, onClose, onRenew }) => {
  if (!cert) return null;

  // Calculate default new expiration (+2 years from current expiration or today if already expired)
  const baseDate = new Date(cert.expirationDate) < new Date() ? new Date() : new Date(cert.expirationDate);
  const defaultNextDate = new Date(baseDate);
  defaultNextDate.setFullYear(defaultNextDate.getFullYear() + 2);
  const defaultNextDateString = defaultNextDate.toISOString().split('T')[0];

  const [newExpiration, setNewExpiration] = useState(defaultNextDateString);
  const [ceuSubmitted, setCeuSubmitted] = useState<number>(cert.ceuCredits || 20);
  const [authorizedBy, setAuthorizedBy] = useState('Director of Continuing Credentialing');
  const [notes, setNotes] = useState('Satisfactory completion of recertification audit, safety hours, and continuing education review.');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    onRenew(cert.id, {
      newExpiration,
      ceuSubmitted: Number(ceuSubmitted),
      authorizedBy,
      notes,
    });
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-lg w-full overflow-hidden text-slate-100">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <RefreshCw className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-semibold text-white tracking-tight">
                Recertification & Renewal Authorization
              </h2>
              <p className="text-xs text-slate-400">
                Extend credential validity and log continuing education
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Credential summary */}
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg space-y-1">
            <div className="text-slate-400">Candidate / Holder:</div>
            <div className="text-sm font-semibold text-white">{cert.recipientName} ({cert.recipientId})</div>
            <div className="text-slate-300 font-medium">{cert.credentialTitle}</div>
            <div className="text-slate-400 font-mono text-[11px]">Current Expiration: {cert.expirationDate}</div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              New Expiration Date
            </label>
            <div className="relative">
              <input
                type="date"
                required
                value={newExpiration}
                onChange={(e) => setNewExpiration(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Continuing Education Units (CEU) / Clock Hours Verified
            </label>
            <input
              type="number"
              min="0"
              max="200"
              required
              value={ceuSubmitted}
              onChange={(e) => setCeuSubmitted(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500 tabular-nums"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Authorizing Accreditation Official
            </label>
            <input
              type="text"
              required
              value={authorizedBy}
              onChange={(e) => setAuthorizedBy(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Renewal Audit Notes & Justification
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors font-medium flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Authorize & Issue Renewal</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
