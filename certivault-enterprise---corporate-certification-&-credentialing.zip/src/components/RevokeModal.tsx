import React, { useState } from 'react';
import { Certification } from '../types/credential';
import { X, Ban, AlertTriangle } from 'lucide-react';

interface RevokeModalProps {
  cert: Certification | null;
  onClose: () => void;
  onRevoke: (certId: string, revocationData: {
    reason: string;
    revokedBy: string;
    noticeRef: string;
  }) => void;
}

export const RevokeModal: React.FC<RevokeModalProps> = ({ cert, onClose, onRevoke }) => {
  if (!cert) return null;

  const [reason, setReason] = useState('Mandatory compliance audit failure / ethics committee determination.');
  const [revokedBy, setRevokedBy] = useState('Chief Regulatory Compliance Officer');
  const [noticeRef, setNoticeRef] = useState(`REV-${cert.id.replace('CERT-', '')}-${Math.floor(100 + Math.random() * 900)}`);
  const [confirmed, setConfirmed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmed) return;

    onRevoke(cert.id, {
      reason,
      revokedBy,
      noticeRef,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-red-900/60 rounded-xl shadow-2xl max-w-lg w-full overflow-hidden text-slate-100">
        <div className="flex items-center justify-between px-6 py-4 border-b border-red-950 bg-red-950/20">
          <div className="flex items-center gap-2.5">
            <Ban className="w-5 h-5 text-red-400" />
            <div>
              <h2 className="text-base font-semibold text-white tracking-tight">
                Administrative Credential Revocation
              </h2>
              <p className="text-xs text-red-300">
                Immediately suspend or revoke credential in verification registry
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="p-3 bg-red-950/30 border border-red-900/40 rounded-lg space-y-1">
            <div className="flex items-center gap-2 text-red-400 font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Permanent Regulatory Action Warning</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Revoking this credential will update its public status to <strong className="text-red-400">REVOKED</strong> on the verification portal and append a cryptographic revocation event record.
            </p>
            <div className="text-slate-200 font-mono text-[11px] pt-1">
              Target ID: <span className="font-bold">{cert.id}</span> · {cert.recipientName}
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Official Revocation Reason / Grounds
            </label>
            <textarea
              rows={2}
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Revoking Authority / Hearing Officer
            </label>
            <input
              type="text"
              required
              value={revokedBy}
              onChange={(e) => setRevokedBy(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Formal Notice Reference Number
            </label>
            <input
              type="text"
              required
              value={noticeRef}
              onChange={(e) => setNoticeRef(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-red-500 font-mono"
            />
          </div>

          <label className="flex items-start gap-2.5 p-3 bg-slate-950/80 border border-slate-800 rounded-lg cursor-pointer">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-0.5 rounded border-slate-700 text-red-600 focus:ring-red-500"
            />
            <span className="text-slate-300 text-[11px] leading-relaxed">
              I certify that due process has been observed and this revocation action is entered into the corporate registry pursuant to accredited accreditation governance standards.
            </span>
          </label>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!confirmed}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors font-medium flex items-center gap-1.5"
            >
              <Ban className="w-3.5 h-3.5" />
              <span>Confirm & Revoke Credential</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
