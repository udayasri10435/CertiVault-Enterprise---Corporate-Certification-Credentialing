import React from 'react';

interface SecuritySealProps {
  theme?: 'classic_navy' | 'emerald_clinical' | 'amber_industrial' | 'modern_dark';
  organization: string;
  size?: number;
}

export const SecuritySeal: React.FC<SecuritySealProps> = ({
  theme = 'classic_navy',
  organization,
  size = 110,
}) => {
  const getThemeColors = () => {
    switch (theme) {
      case 'emerald_clinical':
        return {
          primary: '#059669',
          accent: '#10b981',
          gold: '#f59e0b',
          text: '#064e3b',
          starColor: '#fbbf24',
        };
      case 'amber_industrial':
        return {
          primary: '#d97706',
          accent: '#b45309',
          gold: '#f59e0b',
          text: '#78350f',
          starColor: '#f59e0b',
        };
      case 'modern_dark':
        return {
          primary: '#3b82f6',
          accent: '#6366f1',
          gold: '#e2e8f0',
          text: '#0f172a',
          starColor: '#60a5fa',
        };
      case 'classic_navy':
      default:
        return {
          primary: '#1e3a8a',
          accent: '#3b82f6',
          gold: '#d97706',
          text: '#172554',
          starColor: '#f59e0b',
        };
    }
  };

  const colors = getThemeColors();

  return (
    <div
      className="relative flex items-center justify-center select-none"
      style={{ width: size, height: size }}
      aria-label="Official Corporate Security Seal"
    >
      <svg
        viewBox="0 0 200 200"
        width={size}
        height={size}
        className="drop-shadow-sm"
      >
        <defs>
          <path
            id="seal-text-path-top"
            d="M 30,100 A 70,70 0 0,1 170,100"
            fill="none"
          />
          <path
            id="seal-text-path-bottom"
            d="M 170,100 A 70,70 0 0,1 30,100"
            fill="none"
          />
          <linearGradient id={`seal-grad-${theme}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#f8fafc" stopOpacity="0.7" />
          </linearGradient>
        </defs>

        {/* Outer serrated rosette teeth */}
        <g transform="translate(100,100)">
          {Array.from({ length: 36 }).map((_, i) => (
            <polygon
              key={i}
              points="-3,-96 3,-96 0,-100"
              fill={colors.gold}
              transform={`rotate(${i * 10})`}
            />
          ))}
        </g>

        {/* Outer Ring */}
        <circle cx="100" cy="100" r="95" fill="none" stroke={colors.gold} strokeWidth="3" />
        <circle cx="100" cy="100" r="91" fill="none" stroke={colors.primary} strokeWidth="1.5" strokeDasharray="3,2" />
        <circle cx="100" cy="100" r="68" fill="none" stroke={colors.gold} strokeWidth="2" />

        {/* Inner background fill */}
        <circle cx="100" cy="100" r="66" fill={`url(#seal-grad-${theme})`} />

        {/* Top curved text */}
        <text
          fontSize="9"
          fontWeight="bold"
          letterSpacing="1.8"
          fill={colors.text}
          textAnchor="middle"
        >
          <textPath href="#seal-text-path-top" startOffset="50%">
            OFFICIAL ACCREDITATION SEAL
          </textPath>
        </text>

        {/* Bottom curved text */}
        <text
          fontSize="7.5"
          fontWeight="600"
          letterSpacing="1.2"
          fill={colors.text}
          textAnchor="middle"
        >
          <textPath href="#seal-text-path-bottom" startOffset="50%">
            AUTHENTICATED · ISO 17024
          </textPath>
        </text>

        {/* Center Insignia: Shield with star & check */}
        <g transform="translate(100,100)">
          {/* Subtle sunburst rays */}
          {Array.from({ length: 12 }).map((_, i) => (
            <line
              key={i}
              x1="0"
              y1="-44"
              x2="0"
              y2="-52"
              stroke={colors.gold}
              strokeWidth="1"
              opacity="0.6"
              transform={`rotate(${i * 30})`}
            />
          ))}

          {/* Central Shield */}
          <path
            d="M 0,-28 L 22,-16 L 22,8 C 22,24 0,34 0,34 C 0,34 -22,24 -22,8 L -22,-16 Z"
            fill={colors.primary}
            stroke={colors.gold}
            strokeWidth="1.5"
          />

          {/* Center Star / Symbol */}
          <polygon
            points="0,-16 4,-7 14,-7 6,0 9,10 0,3 -9,10 -6,0 -14,-7 -4,-7"
            fill={colors.starColor}
          />

          <text
            x="0"
            y="20"
            fontSize="6.5"
            fontWeight="bold"
            fill="#ffffff"
            textAnchor="middle"
            letterSpacing="0.8"
          >
            VERIFIED
          </text>
        </g>
      </svg>
    </div>
  );
};
