import React, { useState } from 'react';
import { Certification, CredentialStatus, VerificationResult } from '../types/credential';
import { calculateSHA256, getCanonicalCredentialPayload, computeCredentialStatus } from '../utils/crypto';
import {
  ShieldCheck,
  Search,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Ban,
  Clock,
  Blocks,
  FileCheck,
  Eye,
  Hash,
  ExternalLink,
} from 'lucide-react';

interface VerificationPortalViewProps {
  credentials: Certification[];
  onOpenCertificate: (cert: Certification) => void;
  onOpenBlockchain: (cert: Certification) => void;
  prefillId?: string;
}

export const VerificationPortalView: React.FC<VerificationPortalViewProps> = ({
  credentials,
  onOpenCertificate,
  onOpenBlockchain,
  prefillId = '',
}) => {
  const [searchInput, setSearchInput] = useState(prefillId);
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(() => {
    if (prefillId) {
      const match = credentials.find(c => c.id.toLowerCase() === prefillId.toLowerCase() || c.verificationHash === prefillId);
      if (match) {
        const computedStatus = computeCredentialStatus(match);
        return {
          valid: computedStatus !== 'EXPIRED' && computedStatus !== 'REVOKED',
          status: computedStatus,
          credential: match,
          tampered: false,
          computedHash: match.verificationHash,
          expectedHash: match.verificationHash,
          blockchainVerified: match.blockchain.enabled,
          message: computedStatus === 'REVOKED'
            ? 'Credential revoked by authorizing board.'
            : computedStatus === 'EXPIRED'
            ? 'Credential reached its expiration threshold.'
            : 'Cryptographic hash and issuer authority verified.',
          verifiedAt: new Date().toISOString(),
        };
      }
    }
    return null;
  });

  const runVerification = async (query: string, candidateCert?: Certification) => {
    setIsVerifying(true);
    const cleaned = query.trim();

    // Find in credentials
    let target = candidateCert;
    if (!target) {
      target = credentials.find(
        (c) =>
          c.id.toLowerCase() === cleaned.toLowerCase() ||
          c.verificationHash.toLowerCase() === cleaned.toLowerCase() ||
          (c.blockchain?.txHash && c.blockchain.txHash.toLowerCase() === cleaned.toLowerCase())
      );
    }

    if (!target) {
      // Simulate real calculation for unknown hash
      const computedHash = await calculateSHA256(cleaned);
      setResult({
        valid: false,
        status: 'EXPIRED',
        tampered: false,
        computedHash,
        message: 'No accredited credential found matching this ID, Hash, or Transaction record in the corporate registry.',
        verifiedAt: new Date().toISOString(),
      });
      setIsVerifying(false);
      return;
    }

    // Recompute SHA-256 from target canonical payload
    const canonicalPayload = getCanonicalCredentialPayload(target);
    const computedHash = await calculateSHA256(canonicalPayload);

    // Check tampering
    const isTampered = computedHash !== target.verificationHash;
    const computedStatus = computeCredentialStatus(target);

    let message = 'Cryptographic SHA-256 digest match confirmed. Digital signature validated against accredited authority.';
    if (isTampered) {
      message = 'CRITICAL TAMPER WARNING: Computed payload digest does not match issued seal hash. Unauthorized modification detected.';
    } else if (computedStatus === 'REVOKED') {
      message = `CREDENTIAL REVOKED: Administrative revocation issued on ${target.revocation?.revokedAt ? new Date(target.revocation.revokedAt).toLocaleDateString() : 'record'}.`;
    } else if (computedStatus === 'EXPIRED') {
      message = `EXPIRED: Credential validity lapsed on ${target.expirationDate}. Continuing education or re-certification required.`;
    } else if (computedStatus === 'EXPIRING_SOON') {
      message = `VALID (EXPIRING SOON): Credential active through ${target.expirationDate}. Recertification window is currently active.`;
    }

    setResult({
      valid: !isTampered && computedStatus !== 'EXPIRED' && computedStatus !== 'REVOKED',
      status: computedStatus,
      credential: target,
      tampered: isTampered,
      computedHash,
      expectedHash: target.verificationHash,
      blockchainVerified: target.blockchain.enabled,
      message,
      verifiedAt: new Date().toISOString(),
    });

    setIsVerifying(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      runVerification(searchInput);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        // Look for ID in W3C schema or raw schema
        const certId = parsed.id?.replace('urn:uuid:', '') || parsed.credentialSubject?.id || '';
        const found = credentials.find(c => c.id === certId);
        if (found) {
          runVerification(found.id, found);
          setSearchInput(found.id);
        } else {
          // Verify raw uploaded payload
          const hash = await calculateSHA256(text);
          setResult({
            valid: false,
            status: 'EXPIRED',
            tampered: true,
            computedHash: hash,
            message: 'Uploaded JSON credential payload is unrecognized by the authoritative enterprise registry.',
            verifiedAt: new Date().toISOString(),
          });
        }
      } catch {
        alert('Invalid JSON file format. Please upload a valid JSON Verifiable Credential file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Top Hero / Search Banner */}
      <div className="p-6 sm:p-8 bg-slate-900 border border-slate-800 rounded-xl relative overflow-hidden">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>Public & Employer Verification Registry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mb-2">
            Cryptographic Credential Verification
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed mb-6">
            Verify real-time validity, accreditation standards, and cryptographic tamper-invariance
            for professional credentials across IT, Healthcare, and Skilled Trades.
          </p>

          {/* Search Form */}
          <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Enter Credential ID (e.g. CERT-IT-982103) or SHA-256 Hash..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={isVerifying || !searchInput.trim()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium rounded-lg text-sm transition-colors shrink-0 flex items-center justify-center gap-2"
            >
              {isVerifying ? <span>Verifying...</span> : <span>Verify Credential</span>}
            </button>
          </form>

          {/* Quick Demo Pre-fills */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className="font-medium text-slate-500">Quick Test Cases:</span>
            <button
              type="button"
              onClick={() => {
                setSearchInput('CERT-IT-982103');
                runVerification('CERT-IT-982103');
              }}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px] transition-colors"
            >
              CERT-IT-982103 (Active / Blockchain)
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchInput('CERT-MED-592811');
                runVerification('CERT-MED-592811');
              }}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded font-mono text-[11px] transition-colors"
            >
              CERT-MED-592811 (Expiring Soon)
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchInput('CERT-IT-654920');
                runVerification('CERT-IT-654920');
              }}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-red-300 rounded font-mono text-[11px] transition-colors"
            >
              CERT-IT-654920 (Expired)
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchInput('CERT-MED-301928');
                runVerification('CERT-MED-301928');
              }}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-red-400 rounded font-mono text-[11px] transition-colors"
            >
              CERT-MED-301928 (Revoked)
            </button>
          </div>
        </div>

        {/* Upload file alternative */}
        <div className="mt-6 pt-6 border-t border-slate-800 flex items-center justify-between flex-wrap gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Upload className="w-4 h-4 text-slate-400" />
            <span>Have a downloaded W3C Credential JSON file?</span>
          </div>
          <label className="cursor-pointer px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md transition-colors font-medium">
            <span>Browse JSON File</span>
            <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      </div>

      {/* Verification Result Display */}
      {result && (
        <div className="space-y-4">
          {/* Main Status Header Card */}
          <div
            className={`p-6 rounded-xl border ${
              result.tampered
                ? 'bg-red-950/40 border-red-800/80 text-red-100'
                : result.status === 'ACTIVE'
                ? 'bg-emerald-950/30 border-emerald-800/80 text-emerald-100'
                : result.status === 'EXPIRING_SOON'
                ? 'bg-amber-950/30 border-amber-800/80 text-amber-100'
                : result.status === 'EXPIRED'
                ? 'bg-red-950/30 border-red-800/80 text-red-100'
                : 'bg-red-950/40 border-red-800 text-red-100'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start sm:items-center gap-3">
                {result.tampered ? (
                  <Ban className="w-7 h-7 text-red-400 shrink-0" />
                ) : result.status === 'ACTIVE' ? (
                  <CheckCircle2 className="w-7 h-7 text-emerald-400 shrink-0" />
                ) : result.status === 'EXPIRING_SOON' ? (
                  <Clock className="w-7 h-7 text-amber-400 shrink-0" />
                ) : result.status === 'EXPIRED' ? (
                  <AlertTriangle className="w-7 h-7 text-red-400 shrink-0" />
                ) : (
                  <Ban className="w-7 h-7 text-red-500 shrink-0" />
                )}

                <div>
                  <div className="text-lg font-bold tracking-tight">
                    {result.tampered
                      ? 'TAMPERING DETECTED / HASH CORRUPTED'
                      : result.status === 'ACTIVE'
                      ? 'OFFICIALLY VERIFIED & IN GOOD STANDING'
                      : result.status === 'EXPIRING_SOON'
                      ? 'VERIFIED - EXPIRATION APPROACHING'
                      : result.status === 'EXPIRED'
                      ? 'EXPIRED CREDENTIAL - RECERTIFICATION REQUIRED'
                      : 'CREDENTIAL REVOKED BY AUTHORITY'}
                  </div>
                  <div className="text-xs opacity-90 mt-0.5">{result.message}</div>
                </div>
              </div>

              {result.credential && (
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onOpenCertificate(result.credential!)}
                    className="px-3.5 py-1.5 bg-slate-900/90 hover:bg-slate-900 text-white rounded-md text-xs font-medium border border-slate-700/80 flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Official Certificate</span>
                  </button>

                  {result.credential.blockchain.enabled && (
                    <button
                      onClick={() => onOpenBlockchain(result.credential!)}
                      className="px-3.5 py-1.5 bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 rounded-md text-xs font-medium border border-indigo-700 flex items-center gap-1.5 transition-colors"
                    >
                      <Blocks className="w-3.5 h-3.5" />
                      <span>Ledger Proof</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Details Grid if Credential found */}
          {result.credential && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Left 2 Cols: Details */}
              <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                    Credential Subject
                  </span>
                  <div className="text-xl font-bold text-white mt-1">
                    {result.credential.recipientName}
                  </div>
                  <div className="text-xs text-slate-300 font-mono mt-0.5">
                    Candidate ID: {result.credential.recipientId} · {result.credential.recipientEmail}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400">Designation / Title:</span>
                    <div className="text-sm font-semibold text-white mt-0.5">
                      {result.credential.credentialTitle}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Accredited Standard:</span>
                    <div className="text-sm font-medium text-slate-200 mt-0.5">
                      {result.credential.metadata.accreditationStandard || 'ISO/IEC 17024 Accredited'}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Issuing Organization:</span>
                    <div className="text-sm font-medium text-slate-200 mt-0.5">
                      {result.credential.issuingOrganization}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Authorized Signatory:</span>
                    <div className="text-sm font-medium text-slate-200 mt-0.5">
                      {result.credential.authorizedSigner.name} ({result.credential.authorizedSigner.title})
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Issue Date:</span>
                    <div className="text-sm font-mono text-slate-200 mt-0.5">
                      {result.credential.issueDate}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Expiration Date:</span>
                    <div className="text-sm font-mono text-slate-200 mt-0.5">
                      {result.credential.expirationDate}
                    </div>
                  </div>
                </div>

                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                    Verified Competency Inventory
                  </span>
                  <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {result.credential.competencies.map((comp, idx) => (
                      <div key={idx} className="flex items-center gap-2 p-2 bg-slate-950/70 border border-slate-800 rounded">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="text-slate-300">{comp}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {result.credential.revocation && (
                  <div className="p-3 bg-red-950/40 border border-red-900 rounded-lg text-xs space-y-1">
                    <div className="text-red-400 font-bold flex items-center gap-1.5">
                      <Ban className="w-4 h-4" />
                      <span>Official Revocation Log Details</span>
                    </div>
                    <div className="text-slate-300">
                      Revocation Reason: <span className="text-white font-medium">{result.credential.revocation.reason}</span>
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Revoked by: {result.credential.revocation.revokedBy} · Ref: {result.credential.revocation.noticeRef}
                    </div>
                  </div>
                )}
              </div>

              {/* Right 1 Col: Cryptographic Inspection */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 text-xs font-mono">
                <div className="text-xs font-sans text-slate-400 uppercase tracking-wider font-semibold">
                  Cryptographic Integrity
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-slate-950 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500 uppercase font-sans">
                      Verified SHA-256 Digest
                    </div>
                    <div className="text-[11px] text-emerald-400 break-all mt-1">
                      {result.computedHash}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500 uppercase font-sans">
                      Blockchain Anchor Status
                    </div>
                    <div className="mt-1">
                      {result.credential.blockchain.enabled ? (
                        <div className="text-slate-300 space-y-1">
                          <div className="text-emerald-400 font-semibold flex items-center gap-1">
                            <span>✓ Anchored On-Chain</span>
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            Net: {result.credential.blockchain.network}
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            Tx: {result.credential.blockchain.txHash}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            Block #{result.credential.blockchain.blockNumber}
                          </div>
                        </div>
                      ) : (
                        <div className="text-slate-400 text-[11px]">
                          Standard Asymmetric Key Signature (Off-Chain Enterprise Authority)
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500 uppercase font-sans">
                      Audit Verification Timestamp
                    </div>
                    <div className="text-[11px] text-slate-300 mt-1">
                      {new Date(result.verifiedAt).toUTCString()}
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 font-sans leading-relaxed pt-2 border-t border-slate-800">
                  Calculated live in browser runtime using Web Cryptography API (`crypto.subtle.digest`).
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
