import { Certification, IndustryStandardTemplate } from '../types/credential';

export const INDUSTRY_TEMPLATES: IndustryStandardTemplate[] = [
  // IT & Cloud
  {
    title: 'Certified Cloud Solutions Architect - Enterprise Tier',
    industry: 'IT',
    category: 'Cloud Infrastructure & Architecture',
    defaultValidityMonths: 36,
    defaultCeu: 40,
    accreditationStandard: 'ISO/IEC 17024:2012 Systems Engineering',
    competencies: [
      'Multi-Region Resilient Topology',
      'Zero-Trust VPC Peering & IAM Federation',
      'Microservices Orchestration',
      'FinOps Cost Governance'
    ],
    suggestedTheme: 'modern_dark'
  },
  {
    title: 'Enterprise Cyber Defense & Incident Commander',
    industry: 'IT',
    category: 'Information Security',
    defaultValidityMonths: 24,
    defaultCeu: 50,
    accreditationStandard: 'NIST SP 800-53 / SOC 2 Type II',
    competencies: [
      'Threat Hunting & SIEM Correlation',
      'Cryptographic Key Management (PKI)',
      'Forensic Chain of Custody',
      'Ransomware Containment Protocols'
    ],
    suggestedTheme: 'classic_navy'
  },
  {
    title: 'Kubernetes Platform Specialist & SRE Operator',
    industry: 'IT',
    category: 'DevOps & Site Reliability',
    defaultValidityMonths: 24,
    defaultCeu: 30,
    accreditationStandard: 'Cloud Native Computing Foundation (CNCF)',
    competencies: [
      'Ingress Controller Hardening',
      'StatefulSet Failover Management',
      'Prometheus/Grafana Observability',
      'eBPF Network Policy Enforcement'
    ],
    suggestedTheme: 'modern_dark'
  },

  // Healthcare & Clinical
  {
    title: 'Advanced Cardiovascular Life Support (ACLS) Clinician',
    industry: 'HEALTHCARE',
    category: 'Emergency Cardiovascular Care',
    defaultValidityMonths: 24,
    defaultCeu: 16,
    accreditationStandard: 'AHA ECC 2025/2026 Guidelines & ILCOR',
    competencies: [
      'Defibrillation & Synchronized Cardioversion',
      'Systematic Airway Management',
      'Post-Cardiac Arrest Targeted Temperature',
      'High-Risk Pharmacology Administration'
    ],
    suggestedTheme: 'emerald_clinical'
  },
  {
    title: 'HIPAA Security Officer & Clinical Data Steward',
    industry: 'HEALTHCARE',
    category: 'Health Informatics & Regulatory Compliance',
    defaultValidityMonths: 12,
    defaultCeu: 24,
    accreditationStandard: 'HHS OCR HIPAA Security & Breach Notification Rule',
    competencies: [
      'Protected Health Information (ePHI) Encryption',
      'Business Associate Agreement (BAA) Auditing',
      'EHR Audit Log Forensics',
      'Patient Minimum Necessary Disclosure Governance'
    ],
    suggestedTheme: 'classic_navy'
  },
  {
    title: 'Infection Prevention & Controlled Substances Practitioner',
    industry: 'HEALTHCARE',
    category: 'Inpatient Safety & Pharmacology',
    defaultValidityMonths: 12,
    defaultCeu: 20,
    accreditationStandard: 'CDC Healthcare Infection Control Practices (HICPAC)',
    competencies: [
      'Aseptic Barrier Techniques',
      'Sterilization Assurance Monitoring',
      'DEA Schedule II Controlled Drug Waste Audit',
      'Outbreak Surveillance Epidemiology'
    ],
    suggestedTheme: 'emerald_clinical'
  },

  // Trades & Industrial
  {
    title: 'Journeyman Industrial Electrician & High-Voltage Specialist',
    industry: 'TRADES',
    category: 'Electrical Systems & Power Distribution',
    defaultValidityMonths: 36,
    defaultCeu: 32,
    accreditationStandard: 'NFPA 70E & National Electrical Code (NEC)',
    competencies: [
      'Arc Flash Hazard Analysis (40 cal/cm²)',
      '3-Phase Motor Control Center Wiring',
      'Lockout/Tagout (LOTO) Zero-Energy Verification',
      'Transformer Impedance & Grounding Tests'
    ],
    suggestedTheme: 'amber_industrial'
  },
  {
    title: 'OSHA 30-Hour Construction Safety & Hazard Management',
    industry: 'TRADES',
    category: 'Occupational Health & Heavy Construction',
    defaultValidityMonths: 36,
    defaultCeu: 30,
    accreditationStandard: '29 CFR 1926 OSHA Standards for Construction',
    competencies: [
      'Excavation & Trench Shoring Inspection',
      'Fall Arrest System Proof Testing',
      'Confined Space Atmospheric Testing',
      'Cranes & Rigging Signal Certification'
    ],
    suggestedTheme: 'amber_industrial'
  },
  {
    title: 'Master HVAC/R Commercial Systems & EPA 608 Universal',
    industry: 'TRADES',
    category: 'Thermal Dynamics & Refrigerant Compliance',
    defaultValidityMonths: 36,
    defaultCeu: 28,
    accreditationStandard: 'EPA Section 608 Clean Air Act & ASHRAE 15',
    competencies: [
      'Class I/II/III Refrigerant Recovery & Leak Rate Calcs',
      'Variable Refrigerant Flow (VRF) Commissioning',
      'Chiller Compressor Overhaul & Oil Analysis',
      'Combustion Efficiency & CO Flue Diagnostics'
    ],
    suggestedTheme: 'amber_industrial'
  }
];

export const INITIAL_CREDENTIALS: Certification[] = [
  {
    id: 'CERT-IT-982103',
    credentialTitle: 'Certified Cloud Solutions Architect - Enterprise Tier',
    recipientName: 'Dr. Marcus Vance',
    recipientEmail: 'm.vance@apexcloudsystems.io',
    recipientId: 'EMP-74921',
    industry: 'IT',
    category: 'Cloud Infrastructure & Architecture',
    issuingOrganization: 'Apex Global Cloud Academy & ISO 17024 Registry',
    authorizedSigner: {
      name: 'Elena Rostova, Ph.D.',
      title: 'Dean of Technology Certification',
      signatureText: 'Elena Rostova'
    },
    issueDate: '2025-04-15',
    expirationDate: '2028-04-15',
    status: 'ACTIVE',
    competencies: [
      'Multi-Region Resilient Topology',
      'Zero-Trust VPC Peering & IAM Federation',
      'Microservices Orchestration',
      'FinOps Cost Governance'
    ],
    ceuCredits: 40,
    verificationHash: 'd7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x3f9821b0aa91283d578912eeb87163c4e91024bd78103c80ff129381745ad912',
      blockNumber: 49102834,
      merkleRoot: '0xd7a8fbb307d7809469ca9abcb0082e4f99841029384758291039485729104859',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2025-04-15T14:32:00Z'
    },
    metadata: {
      jurisdiction: 'United States & Global Multi-Cloud',
      accreditationStandard: 'ISO/IEC 17024:2012',
      scorePercent: 96,
      certificateTheme: 'modern_dark',
      gradeLevel: 'Distinction / Lead Practitioner'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-IT-814209',
    credentialTitle: 'Enterprise Cyber Defense & Incident Commander',
    recipientName: 'Sarah K. Chen',
    recipientEmail: 's.chen@defenseguard.org',
    recipientId: 'EMP-38290',
    industry: 'IT',
    category: 'Information Security',
    issuingOrganization: 'National Cyber Defense Consortium',
    authorizedSigner: {
      name: 'Robert J. Sterling',
      title: 'Chief Cryptographic Auditor',
      signatureText: 'Robert J. Sterling'
    },
    issueDate: '2024-11-10',
    expirationDate: '2026-11-10', // Active within ~40 days from simulated time
    status: 'EXPIRING_SOON',
    competencies: [
      'Threat Hunting & SIEM Correlation',
      'Cryptographic Key Management (PKI)',
      'Forensic Chain of Custody',
      'Ransomware Containment Protocols'
    ],
    ceuCredits: 50,
    verificationHash: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x81b7e41103c8008273615243810294857291048591024bd78103c80ff1293817',
      blockNumber: 48392110,
      merkleRoot: '0x5e884898da28047151d0e56f8dc629270094829103948572910485938475829',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2024-11-10T09:15:22Z'
    },
    metadata: {
      jurisdiction: 'North American Cyber Grid',
      accreditationStandard: 'NIST SP 800-53 Rev 5',
      scorePercent: 92,
      certificateTheme: 'classic_navy',
      gradeLevel: 'Senior Incident Commander'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-IT-654920',
    credentialTitle: 'Kubernetes Platform Specialist & SRE Operator',
    recipientName: 'David O\'Connor',
    recipientEmail: 'doconnor@cloudcore.io',
    recipientId: 'EMP-90214',
    industry: 'IT',
    category: 'DevOps & Site Reliability',
    issuingOrganization: 'Apex Global Cloud Academy & ISO 17024 Registry',
    authorizedSigner: {
      name: 'Elena Rostova, Ph.D.',
      title: 'Dean of Technology Certification',
      signatureText: 'Elena Rostova'
    },
    issueDate: '2024-02-01',
    expirationDate: '2026-02-01', // Expired
    status: 'EXPIRED',
    competencies: [
      'Ingress Controller Hardening',
      'StatefulSet Failover Management',
      'Prometheus/Grafana Observability'
    ],
    ceuCredits: 30,
    verificationHash: '8f434346648f6b96df89dda901c5176b10e6d83961dd3c1ac88b59b2dc327aa4',
    blockchain: {
      enabled: false
    },
    metadata: {
      jurisdiction: 'Global',
      accreditationStandard: 'CNCF CKA Standard',
      scorePercent: 88,
      certificateTheme: 'modern_dark'
    },
    renewalHistory: []
  },

  // Healthcare
  {
    id: 'CERT-MED-442918',
    credentialTitle: 'Advanced Cardiovascular Life Support (ACLS) Clinician',
    recipientName: 'Dr. Rebecca Aris',
    recipientEmail: 'r.aris@memorialhospital.org',
    recipientId: 'MD-88192',
    industry: 'HEALTHCARE',
    category: 'Emergency Cardiovascular Care',
    issuingOrganization: 'St. Jude Clinical Medical Board & Resuscitation Academy',
    authorizedSigner: {
      name: 'Dr. Anthony M. Mercer, MD, FACC',
      title: 'Chair of Clinical Resuscitation',
      signatureText: 'Anthony M. Mercer'
    },
    issueDate: '2025-08-20',
    expirationDate: '2027-08-20',
    status: 'ACTIVE',
    competencies: [
      'Defibrillation & Synchronized Cardioversion',
      'Systematic Airway Management',
      'Post-Cardiac Arrest Targeted Temperature',
      'High-Risk Pharmacology Administration'
    ],
    ceuCredits: 16,
    verificationHash: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x17c9e5920021b0aa91283d578912eeb87163c4e91024bd78103c80ff12938174',
      blockNumber: 49450129,
      merkleRoot: '0x4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2025-08-20T11:00:00Z'
    },
    metadata: {
      jurisdiction: 'State Board of Medicine & AHA Standards',
      accreditationStandard: 'AHA ECC Guidelines 2026',
      scorePercent: 99,
      certificateTheme: 'emerald_clinical',
      gradeLevel: 'Clinical Code Team Leader'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-MED-592811',
    credentialTitle: 'HIPAA Security Officer & Clinical Data Steward',
    recipientName: 'Claire DuMont',
    recipientEmail: 'c.dumont@mercyhealthsystem.net',
    recipientId: 'STAFF-19402',
    industry: 'HEALTHCARE',
    category: 'Health Informatics & Regulatory Compliance',
    issuingOrganization: 'Healthcare Privacy & Security Accreditation Board',
    authorizedSigner: {
      name: 'Karen Lindqvist, JD, CHPS',
      title: 'Executive Director of Health Compliance',
      signatureText: 'Karen Lindqvist'
    },
    issueDate: '2025-10-18',
    expirationDate: '2026-10-18', // Expiring in ~20 days from simulated time
    status: 'EXPIRING_SOON',
    competencies: [
      'Protected Health Information (ePHI) Encryption',
      'Business Associate Agreement (BAA) Auditing',
      'EHR Audit Log Forensics',
      'Patient Minimum Necessary Disclosure Governance'
    ],
    ceuCredits: 24,
    verificationHash: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x992427ae41e4649b934ca495991b7852b8553f9821b0aa91283d578912eeb871',
      blockNumber: 49810239,
      merkleRoot: '0xef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2025-10-18T16:20:00Z'
    },
    metadata: {
      jurisdiction: 'United States Department of Health and Human Services (HHS)',
      accreditationStandard: '45 CFR Part 160 and Part 164',
      scorePercent: 95,
      certificateTheme: 'emerald_clinical'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-MED-301928',
    credentialTitle: 'Infection Prevention & Controlled Substances Practitioner',
    recipientName: 'Carlos M. Alvarez, RN',
    recipientEmail: 'carlos.alvarez@northmemorial.org',
    recipientId: 'RN-55291',
    industry: 'HEALTHCARE',
    category: 'Inpatient Safety & Pharmacology',
    issuingOrganization: 'St. Jude Clinical Medical Board & Resuscitation Academy',
    authorizedSigner: {
      name: 'Dr. Anthony M. Mercer, MD, FACC',
      title: 'Chair of Clinical Resuscitation',
      signatureText: 'Anthony M. Mercer'
    },
    issueDate: '2024-06-12',
    expirationDate: '2025-06-12',
    status: 'REVOKED',
    competencies: [
      'Aseptic Barrier Techniques',
      'Sterilization Assurance Monitoring',
      'DEA Schedule II Controlled Drug Waste Audit'
    ],
    ceuCredits: 20,
    verificationHash: 'fb8e20fc2e4c3f248c60c39bd652f3c1347298ab97b8b84d99d09641e1311755',
    blockchain: {
      enabled: false
    },
    metadata: {
      jurisdiction: 'State Nursing Commission',
      accreditationStandard: 'CDC HICPAC Standard',
      scorePercent: 91,
      certificateTheme: 'emerald_clinical'
    },
    renewalHistory: [],
    revocation: {
      revokedAt: '2025-01-14T08:30:00Z',
      reason: 'Mandatory clinical audit failure regarding DEA schedule medication chain-of-custody logging.',
      revokedBy: 'State Board Compliance Enforcement Bureau',
      noticeRef: 'REV-NOTIF-2025-081'
    }
  },

  // Trades & Industrial
  {
    id: 'CERT-TRD-729104',
    credentialTitle: 'Journeyman Industrial Electrician & High-Voltage Specialist',
    recipientName: 'Frank T. Kowalski',
    recipientEmail: 'frank.kowalski@precisiontrades.com',
    recipientId: 'TRD-44102',
    industry: 'TRADES',
    category: 'Electrical Systems & Power Distribution',
    issuingOrganization: 'National Trades & Safety Certification Council',
    authorizedSigner: {
      name: 'Master Inspector Harold J. Briggs',
      title: 'Chief Electrical Examiner & NFPA Trustee',
      signatureText: 'Harold J. Briggs'
    },
    issueDate: '2025-03-01',
    expirationDate: '2028-03-01',
    status: 'ACTIVE',
    competencies: [
      'Arc Flash Hazard Analysis (40 cal/cm²)',
      '3-Phase Motor Control Center Wiring',
      'Lockout/Tagout (LOTO) Zero-Energy Verification',
      'Transformer Impedance & Grounding Tests'
    ],
    ceuCredits: 32,
    verificationHash: '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x578912eeb87163c4e91024bd78103c80ff129381745ad9123f9821b0aa91283d',
      blockNumber: 49012903,
      merkleRoot: '0x2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2025-03-01T15:45:00Z'
    },
    metadata: {
      jurisdiction: 'United States & Canada IBEW Inter-State Reciprocity',
      accreditationStandard: 'NFPA 70E & NEC 2026',
      scorePercent: 94,
      certificateTheme: 'amber_industrial',
      gradeLevel: 'Master Journeyman Grade I'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-TRD-661920',
    credentialTitle: 'OSHA 30-Hour Construction Safety & Hazard Management',
    recipientName: 'Maria Guadalupe Hernandez',
    recipientEmail: 'm.hernandez@summitbuilders.corp',
    recipientId: 'TRD-90312',
    industry: 'TRADES',
    category: 'Occupational Health & Heavy Construction',
    issuingOrganization: 'National Trades & Safety Certification Council',
    authorizedSigner: {
      name: 'Master Inspector Harold J. Briggs',
      title: 'Chief Electrical Examiner & NFPA Trustee',
      signatureText: 'Harold J. Briggs'
    },
    issueDate: '2024-09-15',
    expirationDate: '2027-09-15',
    status: 'ACTIVE',
    competencies: [
      'Excavation & Trench Shoring Inspection',
      'Fall Arrest System Proof Testing',
      'Confined Space Atmospheric Testing',
      'Cranes & Rigging Signal Certification'
    ],
    ceuCredits: 30,
    verificationHash: 'fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9',
    blockchain: {
      enabled: false
    },
    metadata: {
      jurisdiction: 'Federal OSHA 29 CFR 1926 Enforcement',
      accreditationStandard: 'OSHA Outreach Training Program',
      scorePercent: 98,
      certificateTheme: 'amber_industrial'
    },
    renewalHistory: []
  },
  {
    id: 'CERT-TRD-510934',
    credentialTitle: 'Master HVAC/R Commercial Systems & EPA 608 Universal',
    recipientName: 'Douglas Sterling',
    recipientEmail: 'd.sterling@arcticflow.com',
    recipientId: 'TRD-18920',
    industry: 'TRADES',
    category: 'Thermal Dynamics & Refrigerant Compliance',
    issuingOrganization: 'National Trades & Safety Certification Council',
    authorizedSigner: {
      name: 'Master Inspector Harold J. Briggs',
      title: 'Chief Electrical Examiner & NFPA Trustee',
      signatureText: 'Harold J. Briggs'
    },
    issueDate: '2023-10-05',
    expirationDate: '2026-10-05', // Expiring in a few days from simulated time
    status: 'EXPIRING_SOON',
    competencies: [
      'Class I/II/III Refrigerant Recovery & Leak Rate Calcs',
      'Variable Refrigerant Flow (VRF) Commissioning',
      'Chiller Compressor Overhaul & Oil Analysis'
    ],
    ceuCredits: 28,
    verificationHash: '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',
    blockchain: {
      enabled: true,
      network: 'Polygon PoS Enterprise',
      txHash: '0x129381745ad9123f9821b0aa91283d578912eeb87163c4e91024bd78103c80ff',
      blockNumber: 47910283,
      merkleRoot: '0x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',
      contractAddress: '0x89205A3A3b2A5561fE28e08A2A5A4b29C4b9104A',
      anchoredAt: '2023-10-05T12:00:00Z'
    },
    metadata: {
      jurisdiction: 'EPA Clean Air Act Title VI Compliance',
      accreditationStandard: 'EPA Section 608 Universal Class',
      scorePercent: 90,
      certificateTheme: 'amber_industrial'
    },
    renewalHistory: []
  }
];
