export type Industry = 'IT' | 'HEALTHCARE' | 'TRADES';

export type CredentialStatus = 'ACTIVE' | 'EXPIRING_SOON' | 'EXPIRED' | 'REVOKED';

export type CertificateTheme = 'classic_navy' | 'emerald_clinical' | 'amber_industrial' | 'modern_dark';

export interface BlockchainAnchor {
  enabled: boolean;
  network?: 'Polygon PoS Enterprise' | 'Ethereum Mainnet Anchor' | 'Hyperledger Besu Consortia';
  txHash?: string;
  blockNumber?: number;
  merkleRoot?: string;
  contractAddress?: string;
  anchoredAt?: string;
}

export interface RenewalRecord {
  id: string;
  renewedAt: string;
  previousExpiration: string;
  newExpiration: string;
  authorizedBy: string;
  ceuSubmitted: number;
  notes?: string;
}

export interface RevocationRecord {
  revokedAt: string;
  reason: string;
  revokedBy: string;
  noticeRef: string;
}

export interface Certification {
  id: string;
  credentialTitle: string;
  recipientName: string;
  recipientEmail: string;
  recipientId: string;
  industry: Industry;
  category: string;
  issuingOrganization: string;
  authorizedSigner: {
    name: string;
    title: string;
    signatureText: string;
  };
  issueDate: string; // YYYY-MM-DD
  expirationDate: string; // YYYY-MM-DD
  status: CredentialStatus;
  competencies: string[];
  ceuCredits: number;
  verificationHash: string; // SHA-256
  blockchain: BlockchainAnchor;
  metadata: {
    jurisdiction?: string;
    accreditationStandard?: string;
    scorePercent?: number;
    certificateTheme: CertificateTheme;
    gradeLevel?: string;
  };
  renewalHistory: RenewalRecord[];
  revocation?: RevocationRecord;
}

export interface VerificationResult {
  valid: boolean;
  status: CredentialStatus;
  credential?: Certification;
  tampered: boolean;
  computedHash: string;
  expectedHash?: string;
  blockchainVerified?: boolean;
  message: string;
  verifiedAt: string;
}

export interface IndustryStandardTemplate {
  title: string;
  industry: Industry;
  category: string;
  defaultValidityMonths: number;
  defaultCeu: number;
  accreditationStandard: string;
  competencies: string[];
  suggestedTheme: CertificateTheme;
}
